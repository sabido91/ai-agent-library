# Consumer Evidence Synthesis

## Decision to inform

- Decision:
- What must be learned:
- Assumptions:
- Scope and boundaries:

## 1. Executive synthesis

| Finding | Evidence / datum | Insight / interpretation | Strength and rationale | Decision relevance and rationale | So what |
|---|---|---|---|---|---|
|  |  |  |  |  |  |

## 2. Evidence audit

| Source type | Units / base | Target / context | What it is useful for | Key limitations |
|---|---|---|---|---|
|  |  |  |  |  |

## 3. Evidence table and quote bank

| Evidence ID | Source / context | Evidence or verbatim | Code | Theme | Interpretation | Evidence strength | Limitation |
|---|---|---|---|---|---|---|---|
|  |  |  |  |  |  |  |  |

## 4. Consumer understanding

| Theme | JTBD / pain / gain | Driver or barrier | Occasion / context | Supporting evidence | Strength | Gap to validate |
|---|---|---|---|---|---|---|
|  |  |  |  |  |  |  |

## 5. Contradictions, gaps and claim boundaries

- What consumers say:
- What they report doing:
- Observed behaviour:
- Conflicting or disconfirming evidence:
- Segment / occasion differences:
- What did not surface:
- What cannot be concluded:

| Claim or conclusion | What the evidence permits | What it does not permit | Evidence needed to advance |
|---|---|---|---|
|  |  |  |  |

## 6. Decision translation

| Finding | Innovation implication | Confidence | Decision supported now | Still needs validation | Recommended next step |
|---|---|---|---|---|---|
|  |  |  |  |  |  |

## Recommended next step

## What evidence is still missing

## What decision this helps unlock
