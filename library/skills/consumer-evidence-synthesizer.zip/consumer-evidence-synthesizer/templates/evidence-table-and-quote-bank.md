# Evidence Table and Quote Bank

| Evidence ID | Source type | Source / context | Unit ID | Target / segment | Occasion | Question / stimulus | Date | Evidence or verbatim | Evidence type | Code | Theme | Interpretation | Evidence strength | Decision relevance | Limitation |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| E-001 |  |  |  |  |  |  |  |  | Direct consumer evidence |  |  |  |  |  |  |
