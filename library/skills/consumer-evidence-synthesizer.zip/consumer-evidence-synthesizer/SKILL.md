---
name: consumer-evidence-synthesizer
description: Analyze and synthesize qualitative consumer evidence from interviews, focus groups, open-ended survey responses, reviews, observation notes, diaries and Voice of Consumer sources. Use when the user asks to code, analyze, synthesize or compare consumer evidence; identify themes, tensions, Jobs to Be Done, pains, gains, barriers, drivers or contradictions; build an evidence table or quote bank; assess evidence strength; or translate qualitative findings into innovation implications. Preserve traceability from source evidence to interpretation and decision. Do not use for research-instrument design, simulated consumer reactions, quantitative statistical analysis, or personas unsupported by sufficient evidence.
---

# Consumer Evidence Synthesizer

Transform raw qualitative consumer material into an auditable, decision-oriented evidence base. Preserve the chain from source material to coding, interpretation, conclusion and innovation implication.

This skill supports consumer insight and innovation work, especially in FMCG, beverages, nutrition, snacks, retail and horeca. It does not generate consumer evidence, establish population prevalence, validate market size or replace quantitative research.

## When to use

Use this skill when the input includes interviews, focus groups, interview notes, open-ended survey responses, product reviews, social comments, diaries, ethnographic or observation notes, complaint themes, call-centre feedback, sales-team feedback, or other Voice of Consumer material.

Use it to:

- Code and synthesize qualitative evidence
- Build a quote bank or evidence table
- Identify themes, tensions, patterns, contradictions, drivers and barriers
- Extract supported Jobs to Be Done, pains and gains
- Compare segments, contexts, occasions or sources
- Assess evidence strength and decision relevance
- Translate findings into implications and next validation steps

Do not use this skill to:

- Design an interview guide, questionnaire or research study
- Simulate consumer reactions or create synthetic respondents
- Estimate incidence, market share, demand, sample significance or statistical confidence
- Create a validated persona from sparse evidence
- Make legal, regulatory, nutritional, medical or pricing claims

## Inputs

Use the material provided by the user. Identify what is available and what is missing.

Preferred inputs:

- Business decision to inform
- Research objective or decision context
- Raw source material and source labels
- Participant, segment, occasion, market and date metadata
- Question asked or stimulus shown, where applicable
- Known sample size, recruitment method and study limitations
- Existing hypotheses or internal assumptions, labelled as such

If the decision is missing, infer it only when clearly implied. Otherwise ask up to three sharp questions before proceeding. If the evidence is sufficient to produce a useful provisional synthesis, proceed and label assumptions.

## Non-negotiable evidence rules

- Treat direct consumer material, researcher interpretation, internal assumption and AI inference as distinct types of information.
- Never convert qualitative recurrence into market incidence, percentages, prevalence or representativeness.
- Never claim that a population, target or market believes something unless appropriate representative quantitative evidence is supplied.
- Preserve verbatims exactly. Do not rewrite, tidy, translate or combine text and label it as a direct quote. If shortening a verbatim, use ellipses without changing its meaning. Label material as a translation when relevant.
- A strong quote is evidence of one participant's expression, not evidence of prevalence.
- Do not count several sentences from one participant, interview or review as independent confirmation.
- Search actively for disconfirming, mixed and contradictory material, not only evidence that supports the dominant interpretation.
- Do not create demographic, behavioural, attitudinal or motivational attributes that do not appear in the evidence.
- Do not treat non-mention as non-importance. State “not surfaced in the available material” unless the prompt, stimulus and context make absence interpretable.
- When a conclusion is not sufficiently supported, state “Gap to validate” instead of completing the story.
- Separate evidence strength from business or decision relevance. A weak signal can still deserve validation if its potential impact is high.
- Protect privacy. Do not repeat personal identifiers unless essential and authorised. Use participant/source IDs rather than names.

## Workflow

Follow these seven steps in order. Do not skip the audit and coding steps merely because a compelling quote appears early.

### 1. Establish the business decision

State the decision this synthesis should inform. Examples include product proposition, concept refinement, claim wording, pack hierarchy, target, occasion, price/value hypothesis, channel, communication or next research step.

Output:

- Decision to inform
- What must be learned
- Assumptions already present
- Boundaries of the analysis

### 2. Audit the evidence base

Create a short evidence inventory before interpreting material.

For each source or source group identify:

- Source type: moderated qualitative, unmoderated qualitative, observational, open-ended survey, internal, synthetic or other
- Unit of analysis: participant, interview, response, review, observation, diary entry, occasion or episode
- Number of independent units when known
- Target, segment, market, context and occasion
- Question asked or stimulus shown
- Date/time period
- Potential biases and limits

Use these source cautions:

| Source type | Useful for | Key limits |
|---|---|---|
| Moderated interviews/focus groups | motivations, language, reactions, context | small base; moderator and social desirability effects |
| Reviews/comments | spontaneous language, drivers, barriers | self-selection; incomplete context; extreme opinions |
| Open-ended surveys | themes across a known base | limited depth; wording and survey context matter |
| Observation/diaries | behaviour, frictions, situations | small base; observer interpretation; context-specific |
| Internal feedback | hypotheses and emerging signals | not independent consumer evidence |
| Synthetic material | rehearsal and hypothesis generation | never consumer evidence |

### 3. Code before interpreting

Build the chain:

`observation or verbatim → code → pattern → theme → interpretation → implication`

Use close-to-the-data codes first. Prefer the consumer's language where useful. Avoid jumping directly from one quote to a broad theme.

For each source extract:

- Evidence item or verbatim
- Context and source ID
- Initial code
- Theme candidate
- Relevant target, occasion or segment
- Whether the item is direct evidence, interpretation, internal assumption or AI inference

Merge codes into themes only after checking whether similar evidence comes from independent units and comparable contexts.

### 4. Identify patterns, differences and contradictions

Assess, qualitatively and without false precision:

- Recurrence across independent units or sources
- Intensity, emotional salience and specificity
- Spontaneity versus prompted response
- Differences by target, occasion, context, product use or stimulus
- Alternatives, substitutes and workarounds
- Trade-offs and tensions
- What consumers say versus what they report doing versus observed behaviour, if available
- Disconfirming evidence and exceptions

Do not use counts as proof of population incidence. You may state the number of independent units transparently when supplied, for example: “mentioned by 4 of 8 interview participants in this material,” followed by the limitation that this is not a population estimate.

### 5. Extract consumer understanding only when supported

Identify supported themes, drivers, barriers, pains, gains and Jobs to Be Done.

State a Job only when the material contains enough contextual narratives. Use:

`When [situation/context], I want to [motivation/action], so that [desired progress/outcome].`

Do not name a Job from an isolated preference statement. If the evidence is incomplete, report a tentative job hypothesis and the missing elements. A useful quality check for a robust job is multiple complete narratives across independent consumers; aim for 5–10 where the project permits, but do not present this as a universal threshold or a statistical rule.

### 6. Rate evidence strength and decision relevance

Assign evidence strength with a rationale:

| Rating | Meaning |
|---|---|
| Strong | Consistent pattern across several independent, relevant sources or units; clear context; little material contradiction within the available evidence |
| Moderate | Repeated or well-articulated pattern, but limited by sample, source, context or some mixed evidence |
| Weak signal | Isolated, sparse, indirect or context-limited evidence that may be worth testing |
| Hypothesis | Interpretation or proposition not directly established by the available consumer evidence |

Also assign decision relevance:

| Rating | Meaning |
|---|---|
| High | If true, it could materially affect the current decision, proposition, investment or risk |
| Medium | It could improve execution or prioritisation but is unlikely to change the strategic direction alone |
| Low | It is interesting context with limited impact on the immediate decision |

State why each rating was chosen. Never use “strong” merely because a quote is vivid.

### 7. Translate findings into a decision path

For every material finding, provide:

- So what: the decision-relevant interpretation
- Innovation implication: product, proposition, claim, pack, price/value, target, occasion, channel or communication implication
- Confidence and limitation
- Decision supported now
- What cannot yet be decided
- Next validation step

Keep recommendations conditional when evidence is qualitative or incomplete. Avoid turning every interpretation into a recommendation.

## Required output

Unless the user asks for a shorter format, always produce these six blocks.

### 1. Executive synthesis

Provide 3–7 findings relevant to the decision. For each finding distinguish:

- **Evidence / datum:** what was said, observed or recorded
- **Insight / interpretation:** what the evidence may mean
- **Strength:** Strong, Moderate, Weak signal or Hypothesis, with reason
- **Decision relevance:** High, Medium or Low, with reason
- **So what:** implication and next step

### 2. Evidence audit

Summarise the evidence base, source types, units, known coverage, key contextual information and limitations. Explicitly state what the material cannot establish.

### 3. Evidence table and quote bank

Use this table:

| Evidence ID | Source / context | Evidence or verbatim | Code | Theme | Interpretation | Evidence strength | Limitation |
|---|---|---|---|---|---|---|---|

Keep direct quotations in quotation marks and preserve their wording. Use source IDs that allow traceability without exposing personal data.

### 4. Consumer understanding

Use this table:

| Theme | JTBD / pain / gain | Driver or barrier | Occasion / context | Supporting evidence | Strength | Gap to validate |
|---|---|---|---|---|---|---|

### 5. Contradictions, gaps and claim boundaries

Explicitly cover:

- What consumers say
- What they report doing
- Observed behaviour, if supplied
- Conflicting or disconfirming evidence
- Segment, source or occasion differences
- Evidence that did not surface
- What cannot be concluded

Then use this table:

| Claim or conclusion | What the evidence permits | What it does not permit | Evidence needed to advance |
|---|---|---|---|

### 6. Decision translation

Use this table:

| Finding | Innovation implication | Confidence | Decision supported now | Still needs validation | Recommended next step |
|---|---|---|---|---|---|

End with:

- **Recommended next step**
- **What evidence is still missing**
- **What decision this helps unlock**

## Output language and style

Match the user's language. For Portuguese, use Portuguese from Portugal. Use precise, plain, executive language.

Preferred wording in Portuguese:

- “O material qualitativo analisado sugere um padrão recorrente…”
- “Surge um sinal inicial que merece validação…”
- “Uma hipótese de trabalho é…”
- “A evidência é mista: alguns participantes…, enquanto outros…”
- “A evidência disponível não permite estimar prevalência, dimensão ou representatividade.”
- “Este fator não emergiu no material disponível; isso não significa que seja irrelevante.”
- “Antes de decidir sobre X, importa validar Y através de…”

Avoid language such as “consumers want” unless the evidence and scope justify the statement. Prefer “some participants described…”, “the available material indicates…” or “among the sources analysed…”.

## Quality check before finalising

Confirm all of the following:

- The business decision is explicit or labelled as assumed.
- Sources, units and limitations have been audited.
- Findings trace back to evidence items or source IDs.
- Direct evidence, interpretation, hypothesis and recommendation are visibly separated.
- No qualitative pattern has been presented as incidence, population prevalence or market fact.
- At least one possible contradiction, exception or limitation has been sought and reported where applicable.
- Quotes are exact and traceable.
- Jobs, personas and motivations are not invented beyond the material.
- Evidence strength and decision relevance are both stated for material findings.
- The output distinguishes what can be decided now from what still needs validation.
