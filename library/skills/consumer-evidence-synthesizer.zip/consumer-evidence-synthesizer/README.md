# Consumer Evidence Synthesizer

A reusable skill for turning qualitative consumer material into traceable, decision-oriented evidence for FMCG and innovation work.

## What it does

It codes interviews, focus groups, open-ended survey responses, reviews, diaries and observation notes; identifies themes, tensions, Jobs to Be Done, pains, gains, drivers, barriers and contradictions; and makes the boundary between evidence, interpretation, hypothesis and recommendation explicit.

## What it does not do

It does not design research instruments, simulate consumers, estimate population incidence, run quantitative analysis or create validated personas from sparse material.

## Suggested use

Provide the business decision, source material, source labels, original questions or stimuli, relevant metadata and known study limitations. The skill will return an executive synthesis, evidence audit, evidence table, consumer understanding, contradictions and decision translation.

## Initial validation

Test with:

- 5–10 qualitative interviews linked to a concept or proposition
- Open-ended responses from a concept test, with question wording and available segment metadata
- A set of category reviews or feedback, with platform/source context

Review whether outputs remain traceable, avoid false prevalence claims, surface limitations and lead to a usable next decision.
