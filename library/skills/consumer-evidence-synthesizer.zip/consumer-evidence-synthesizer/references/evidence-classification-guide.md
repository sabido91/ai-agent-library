# Evidence Classification Guide

Use these labels consistently:

- **Fact / datum:** A directly supplied observation, verbatim, record, response or measurement. It remains tied to a source.
- **Insight / interpretation:** A reasoned explanation of a pattern in the supplied material. It is not a fact and must retain scope and limitations.
- **Hypothesis:** A plausible proposition requiring further validation; it may arise from evidence, internal knowledge or inference.
- **Recommendation:** A proposed action, decision or test. It is not evidence.

## Evidence strength

- **Strong:** Consistent across several independent, relevant sources or units with clear context and no material contradiction in the supplied evidence.
- **Moderate:** Repeated or well-supported but limited by source, context, sample or mixed evidence.
- **Weak signal:** Isolated, indirect, sparse or context-specific evidence worth monitoring or testing.
- **Hypothesis:** Not directly established by the material.

Evidence strength is not business importance. Record decision relevance separately.

## Common errors to prevent

- Treating qualitative quotes as statistics
- Repeating a claim as if it were independently confirmed when it comes from one respondent
- Calling a sampled theme “what consumers think”
- Treating internal stakeholder belief as consumer evidence
- Treating an AI simulation as research data
- Treating an unmentioned issue as unimportant
- Moving directly from a quote to a recommendation without stating interpretation and limits
