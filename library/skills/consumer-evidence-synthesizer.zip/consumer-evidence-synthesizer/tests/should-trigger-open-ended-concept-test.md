# Should trigger: open-ended concept-test responses

## Request

I have 230 open-ended answers to “What do you like or dislike about this juice concept?” Build an evidence table, compare parents with non-parents if the metadata permits, and tell me what we can decide now.

## Expected behaviour

- Triggers consumer-evidence-synthesizer.
- Requests or flags the original question, concept stimulus and segment metadata if absent.
- Does not infer quantitative prevalence solely from repeated themes in text.
- Separates themes by segment only when source metadata supports it.
- Produces claim boundaries and decision translation.
