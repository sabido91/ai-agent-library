# Should trigger: review mining

## Request

Synthesize these 120 reviews of functional hydration products. Find drivers, barriers, wording consumers use and any differences by consumption occasion.

## Expected behaviour

- Triggers consumer-evidence-synthesizer.
- Flags review self-selection and incomplete context.
- Maintains source traceability.
- Does not call review themes representative of the market.
- Highlights gaps in occasion data rather than inventing them.
