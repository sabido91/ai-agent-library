# Should not trigger: research design

## Request

Create a discussion guide for 60-minute interviews about the role of satiety in afternoon snacking.

## Expected behaviour

- Does not use consumer-evidence-synthesizer as the primary skill.
- Routes to research framing or interview/questionnaire design.
