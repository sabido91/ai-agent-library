# Should trigger: interview synthesis

## Request

Analyse the following eight interviews about a high-protein fruit snack. Identify what consumers value, the barriers to trial, whether there is a plausible job to be done, and what we should change in the proposition.

## Expected behaviour

- Triggers consumer-evidence-synthesizer.
- Audits that eight interviews do not establish prevalence.
- Codes source evidence before forming themes.
- Separates direct quotes from interpretations.
- Identifies contradictions and limitations.
- Gives conditional implications and a next validation step.
