# Mentor Socratic Orchestrator

A personal mentoring skill that keeps one coherent voice while selectively using specialised skills for strategy, innovation, planning and communication.

## Core model

`Mentor → clarify context → identify next problem → one specialist skill if useful → mentor interpretation → user choice → next step`

The mentor is the orchestrator, not a dumping ground for all specialist instructions.

## Installation

Keep this package as a standalone skill. Update `references/skill-routing.md` with the exact names of skills available in your environment. If a referenced specialist skill is not installed, retain the mentor workflow and complete the task conversationally where appropriate.

## Scope

Professional, personal and mixed decisions; priorities; difficult conversations; career; energy and boundaries; projects; innovation; side projects. This is not therapy or regulated professional advice.
