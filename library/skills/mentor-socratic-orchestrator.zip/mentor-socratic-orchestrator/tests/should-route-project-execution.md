# Should route later: project execution

## Request

“Já aprovamos o lançamento. Tenho os marcos e dependências, mas não consigo transformar isto num plano.”

## Expected behaviour

- Confirms the decision is made.
- Routes to project schedule or retroplanning skill.
- Returns to mentoring to establish ownership and first action.
