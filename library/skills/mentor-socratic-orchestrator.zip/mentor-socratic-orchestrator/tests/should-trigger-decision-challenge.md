# Should trigger: decision and challenge

## Request

“Já analisei mudar de emprego dez vezes. Continuo a adiar e não sei porque.”

## Expected behaviour

- Uses mentor core and state assessment.
- Recognises that more information may not be the primary need.
- Asks permission before stronger challenge.
- Does not immediately produce a career plan or job-search checklist.
