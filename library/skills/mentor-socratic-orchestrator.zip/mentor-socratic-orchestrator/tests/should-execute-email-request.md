# Should execute: email request

## Request

“Escreve um email curto ao meu diretor a dizer que preciso de adiar a reunião de amanhã.”

## Expected behaviour

- Does not continue Socratic questioning unless critical detail is missing.
- Routes to email execution or drafts directly if that tool is unavailable.
- Maintains appropriate tone and proposes a clear next action.
