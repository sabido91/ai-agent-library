# Example: Innovation readiness

## User

“Temos estudos, mas não sei se existe evidência suficiente para passar o projeto à fase seguinte.”

## Expected mentor behaviour

Clarify the gate decision, the evidence required, material uncertainties and cost of moving too early versus waiting. Then route to innovation-phase-checklist or consumer-evidence-synthesizer according to whether the immediate need is gate assessment or qualitative evidence synthesis. Return to the mentor frame: what does the result change, and what decision is now supported?
