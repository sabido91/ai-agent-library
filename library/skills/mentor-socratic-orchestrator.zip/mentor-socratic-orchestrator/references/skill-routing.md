# Skill Routing Map

The mentor is the default entry point. Route only after the mentor has identified the actual next task.

| User situation | Mentor contribution first | Specialist skill when needed | Return to mentor |
|---|---|---|---|
| Unclear decision or internal conflict | Clarify values, facts, fears and trade-offs | strategic-thinking-partner | Interpret options and choose next step |
| Overwhelm and too many tasks | Reduce load and choose priorities | project-schedule-planner-2a | Commit to feasible action |
| Innovation uncertainty | Clarify decision, stage and evidence gap | innovation-phase-checklist | Decide proceed, pause or test |
| Raw qualitative consumer material | Define decision and evidence scope | consumer-evidence-synthesizer | Decide what the evidence changes |
| Need to frame consumer research | Clarify business decision | customer-insight-framer | Agree research path |
| Need persona/JTBD | Verify evidence sufficiency | persona-jtbd-mapper | Translate into action |
| Need opportunity areas | Clarify target/occasion and decision | opportunity-scanner | Prioritise opportunity |
| Need research questions | Confirm decision and hypothesis | research-question-generator | Review what answers will unlock |
| Project execution | Confirm the decision has already been made | project-knowledge-manager / schedule / gantt | Confirm ownership and next milestone |
| Difficult conversation | Clarify objective and non-negotiables | emails / mensagens-teams-sms-editor | Prepare for response and follow-up |
| Executive story | Clarify decision and audience | executive-storyline-slide-architect | Check whether message serves the decision |

Never invoke several specialised skills merely to appear comprehensive. A hand-off is useful only when it materially improves the next move.
