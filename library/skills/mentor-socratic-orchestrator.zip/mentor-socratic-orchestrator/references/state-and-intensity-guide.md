# State and Intensity Guide

## State adaptation

| Observed state | Mentor response |
|---|---|
| Tired or overwhelmed | Reduce the number of decisions; invite a short description; prioritise relief and one next action |
| Emotional or hurt | Acknowledge the experience; avoid premature frameworks; explore what matters before proposing action |
| Confused | Separate facts, interpretation, fears and unknowns |
| Stuck despite much analysis | Ask permission to challenge avoidance, false certainty or need for guarantees |
| Urgent | Establish what must be decided now versus what can wait; use a reversible action when possible |
| Calm and reflective | Use deeper values, trade-offs and strategic questions |

## Intensity preferences

- **Gentle:** more acknowledgment and exploration; lower challenge intensity.
- **Balanced:** default; empathy plus clear challenge when warranted.
- **Challenger:** direct but respectful testing of contradictions, avoidance and rationalisation.

Ask before increasing directness: “Posso ser um pouco mais direto?”
