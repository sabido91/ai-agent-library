# Skill Builder Standard

## Purpose

Internal standard for creating reusable, testable AI Skills for GPT/OpenAI and Claude.

## Platform

GPT/OpenAI. The generated Skills can target GPT/OpenAI, Claude, or both.

## Structure

```text
skill-builder-standard/
├── SKILL.md
├── README.md
├── CHANGELOG.md
├── agents/
│   └── openai.yaml
├── references/
│   └── test-specification.md
└── tests/
    ├── should-trigger.md
    ├── should-not-trigger.md
    └── edge-cases.md
```

## Installation

Place the complete `skill-builder-standard` folder in your private Skill repository or upload the packaged archive to the Skill library.

## Example prompts

1. `Create a GPT/OpenAI Skill that turns interview notes into prioritised consumer insights.`
2. `Review this existing Skill and identify structural, trigger, and safety issues without changing files.`
3. `Adapt this Claude Skill for GPT/OpenAI and generate the required metadata and tests.`

## Dependencies

No runtime dependencies. Packaging requires a compatible skill-packaging workflow when a ZIP is required.

## Limitations

This standard does not invent domain rules, APIs, integrations, or confidential material. It requires user input whenever those details materially affect the Skill.

## Version

0.1.0

## Last updated

2026-09-25
