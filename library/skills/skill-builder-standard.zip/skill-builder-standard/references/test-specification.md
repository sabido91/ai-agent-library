# Test specification

## should-trigger.md

Include at least three realistic prompts where the Skill should apply. For each test, provide:

- Prompt
- Expected activation
- Expected behaviour
- Quality criteria

## should-not-trigger.md

Include at least three realistic prompts where the Skill should not apply. For each test, provide:

- Prompt
- Expected non-activation
- Reason
- Preferred alternative behaviour

## edge-cases.md

Include at least three ambiguous, incomplete, or high-risk cases. For each test, provide:

- Prompt or scenario
- Risk or ambiguity
- Expected behaviour
- Safe handling requirement
