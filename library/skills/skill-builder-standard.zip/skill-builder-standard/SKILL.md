---
name: skill-builder-standard
description: Create, review, improve, adapt, repair, and package focused reusable AI Skills for GPT/OpenAI, Claude, or both. Use when a user wants a new Skill from a brief, needs an existing SKILL.md or Skill folder reviewed or updated, needs platform adaptation, or needs a complete tested Skill package. Do not use for general-purpose assistance unrelated to building Skills.
---

# Objective

Create one focused, reusable, testable AI Skill per repeatable workflow or capability. Use this Skill as the internal standard for generated Skills.

## Platform selection

Identify the target platform: GPT/OpenAI, Claude, or both. Ask one concise question only if the platform is absent and it materially changes the deliverable.

For GPT/OpenAI, create `agents/openai.yaml`. For Claude, do not create or retain OpenAI-only metadata. For both, create platform-appropriate variants while preserving the same core purpose, workflow, outputs, quality rules, limits, and tests.

## Intake and assumptions

Read the supplied brief, `SKILL.md`, folder, and relevant files before proposing changes.

Ask no more than three objective clarification questions, and only when answers materially change behaviour, structure, platform compatibility, or outputs. Otherwise, proceed and state explicit `Assunções de desenho`.

Do not make commits, installations, or publications. Treat GitHub as the source of truth; a ZIP is a working deliverable for review before a commit.

## Workflow

1. Classify the request as `create`, `review`, `improve`, `adapt`, `repair`, or `package`. Combine modes only when necessary; apply `review → repair → improve → adapt → package`.
2. Define one clear responsibility, expected inputs, outputs, triggers, anti-triggers, quality criteria, limits, and safety requirements.
3. Select the target platform and determine the minimum justified file structure.
4. Create or update the complete Skill bundle.
5. Preserve valid logic, business rules, examples, intent, and changelog history in existing Skills unless the user explicitly requests otherwise.
6. Update documentation, version history, and tests.
7. Validate structure, YAML frontmatter, coherence, platform-specific files, resource references, and absence of unused folders or sensitive data.
8. Package the complete root folder as a ZIP when file creation is available.
9. Deliver the final tree, summary, assumptions, changed-file inventory, installation guidance, three real-world test prompts, and a review-before-GitHub note.

## Required structure

Generate this minimum structure for every Skill:

```text
skill-name/
├── SKILL.md
├── README.md
├── CHANGELOG.md
└── tests/
    ├── should-trigger.md
    ├── should-not-trigger.md
    └── edge-cases.md
```

Add `references/`, `scripts/`, or `assets/` only when justified by the workflow. Do not create empty folders.

For GPT/OpenAI, add:

```text
agents/
└── openai.yaml
```

## SKILL.md requirements

Use lowercase `kebab-case` for the folder name and the YAML `name`; they must match.

Use YAML frontmatter with a clear `name` and `description`. The description must state what the Skill does, when to use it, and relevant boundaries or anti-triggers.

Include these sections in generated Skills:

- Objective
- When to use
- When not to use
- Expected inputs
- Workflow
- Output format
- Quality rules
- Uncertainty management
- Limits and safety
- References and resources, when applicable

Write an operational, sequential, concrete, and testable workflow. Keep `SKILL.md` concise and move detailed material to `references/` only when required.

## Documentation, tests, and metadata

Create `README.md` with the name and purpose, supported platform, folder tree, installation or repository placement instructions, at least three example prompts, dependencies, known limitations, version, and last updated date.

Create `CHANGELOG.md` using:

```md
# Changelog

## [0.1.0] - YYYY-MM-DD
### Added
- Initial version generated from a user brief.
```

Use the current date only when known with confidence. Preserve historical entries and add new entries above prior entries. Use semantic versioning: `0.1.1` for small fixes, `0.2.0` for compatible functional improvements, `1.0.0` for a stable validated release, and a new major only for incompatible changes or a material change in purpose.

Create all three test files with at least three realistic cases each. See `references/test-specification.md` for the mandatory fields.

For GPT/OpenAI, create `agents/openai.yaml` containing only concise UI metadata: `display_name`, `short_description`, and `default_prompt`.

## References, scripts, and assets

Use `references/` for detailed frameworks, policies, taxonomies, long templates, examples, or standards that are needed only for relevant cases. Link directly from `SKILL.md`; avoid chains of references.

Create `scripts/` only for deterministic, repeatable operations that benefit from automation or validation. Every script must define clear inputs and outputs, avoid hidden side effects, include concise usage, fail safely, and never contain credentials or secrets.

Use `assets/` only for reusable templates or static support files needed in final outputs.

## Quality rules

Before delivery, verify:

- Folder name and frontmatter `name` match.
- The Skill has one focused responsibility.
- The description includes useful triggers and boundaries.
- The workflow is complete, sequential, and verifiable.
- The output format is explicit.
- Each test file includes at least three cases.
- No empty folders, secrets, credentials, confidential data, fabricated tools, APIs, links, sources, or dependencies are present.
- Platform-specific files match the selected platform.
- Existing Skill logic, history, and valid files are preserved where applicable.

If a check fails, correct the package before delivery. Do not claim a validation that was not executed.

## Language and priority

Communicate in Portuguese from Portugal unless requested otherwise. Use English for technical identifiers, folder and file names, YAML keys, and code.

Apply this priority when requirements conflict:

1. Mandatory requirements of the target platform.
2. This internal Skill Builder Standard.
3. Official source material for the selected platform.
4. Open Agent Skills specifications.
5. Other external examples.

Never copy external material verbatim into a generated Skill unless the user explicitly asks and reuse is appropriate.
