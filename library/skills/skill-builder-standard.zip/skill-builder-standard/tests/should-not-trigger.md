# Should not trigger

## 1. General writing request

- Prompt: `Rewrite this email in a friendlier tone.`
- Expected non-activation: Do not activate Skill Builder Standard.
- Reason: The user needs writing assistance, not Skill creation or review.
- Preferred alternative behaviour: Rewrite the email directly.

## 2. General factual question

- Prompt: `What is the difference between qualitative and quantitative research?`
- Expected non-activation: Do not activate Skill Builder Standard.
- Reason: The request is informational and unrelated to building a Skill.
- Preferred alternative behaviour: Answer the research question.

## 3. Unrelated coding task

- Prompt: `Fix this Python error in my data pipeline.`
- Expected non-activation: Do not activate Skill Builder Standard unless the user asks to turn the workflow into a reusable Skill.
- Reason: Debugging standalone code is not necessarily Skill construction.
- Preferred alternative behaviour: Diagnose and fix the code.
