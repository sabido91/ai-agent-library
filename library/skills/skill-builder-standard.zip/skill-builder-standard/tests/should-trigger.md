# Should trigger

## 1. New Skill from a brief

- Prompt: `Create a GPT/OpenAI Skill that reviews executive meeting summaries and extracts decisions, owners, deadlines, and risks.`
- Expected activation: Activate Skill Builder Standard.
- Expected behaviour: Clarify only material gaps, define a focused capability, generate the required structure and GPT/OpenAI metadata.
- Quality criteria: Clear triggers, explicit output format, tests, README, changelog, and no invented integrations.

## 2. Existing Skill review

- Prompt: `Review this SKILL.md for clarity, missing anti-triggers, weak safety guidance, and test coverage. Do not change files.`
- Expected activation: Activate in `review` mode.
- Expected behaviour: Analyse without modifying or packaging files.
- Quality criteria: Prioritised findings, concrete recommendations, and a proposed change plan.

## 3. Platform adaptation

- Prompt: `Adapt this Claude Skill for GPT/OpenAI and preserve its workflow and tests.`
- Expected activation: Activate in `adapt` mode.
- Expected behaviour: Preserve core behaviour and add only justified OpenAI metadata.
- Quality criteria: No Claude-incompatible metadata retained; OpenAI metadata remains concise.
