#!/usr/bin/env python3
import argparse
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument("skill_name")
parser.add_argument("--path", required=True)
args = parser.parse_args()

name = args.skill_name
if name.lower() != name or " " in name or "_" in name or "skill" in name:
    raise SystemExit("Use a lowercase hyphen-separated name that does not include 'skill'.")

root = Path(args.path) / name
(root / "agents").mkdir(parents=True, exist_ok=False)
(root / "SKILL.md").write_text(
    f"---\nname: {name}\ndescription: Describe what this Skill does and when to use it.\n---\n\n# {name}\n\nImplement the workflow here.\n",
    encoding="utf-8",
)
(root / "agents" / "openai.yaml").write_text(
    "interface:\n  display_name: Replace Me\n  short_description: Replace Me\n  default_prompt: Replace Me\n",
    encoding="utf-8",
)
print(root)
