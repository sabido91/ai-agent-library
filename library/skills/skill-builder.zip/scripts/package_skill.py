#!/usr/bin/env python3
import argparse, re, zipfile
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument("skill_folder")
parser.add_argument("output_dir", nargs="?", default=".")
args = parser.parse_args()
root = Path(args.skill_folder)
out = Path(args.output_dir)
skill_md = root / "SKILL.md"
if not skill_md.exists():
    raise SystemExit("Validation failed: SKILL.md is missing.")
text = skill_md.read_text(encoding="utf-8")
match = re.match(r"^---\n(.*?)\n---\n", text, re.S)
if not match:
    raise SystemExit("Validation failed: YAML frontmatter is missing or malformed.")
frontmatter = match.group(1)
name = re.search(r"^name:\s*([^\n]+)$", frontmatter, re.M)
description = re.search(r"^description:\s*(.+)$", frontmatter, re.M)
if not name or not description:
    raise SystemExit("Validation failed: frontmatter must contain name and description.")
if name.group(1).strip().lower() != name.group(1).strip():
    raise SystemExit("Validation failed: name must be lowercase.")
out.mkdir(parents=True, exist_ok=True)
zip_path = out / "skill.zip"
with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as z:
    for p in root.rglob("*"):
        if p.is_file():
            z.write(p, p.relative_to(root.parent))
if zip_path.stat().st_size > 25 * 1024 * 1024:
    zip_path.unlink()
    raise SystemExit("Validation failed: package exceeds 25 MB.")
print(zip_path)
