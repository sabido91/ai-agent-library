# Output patterns

## Clarifying questions

Ask for input, output, and connectors first. Keep the first batch to three concise questions.

## Build completion

Use this order:

1. Mode and purpose.
2. Assumptions.
3. Final tree.
4. Changes.
5. Installation guidance.
6. Three test prompts.
7. `skill.zip`, only when successfully created.

## Review completion

Use this order:

1. Interpreted objective.
2. Strengths.
3. Prioritized problems.
4. Risks and gaps.
5. Recommendations.
6. Questions requiring confirmation.
7. Proposed plan.
