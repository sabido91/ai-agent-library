# Skill-building workflows

## New Skill

1. Clarify concrete examples, input, output, and connectors.
2. Map reusable content to instructions, scripts, references, or assets.
3. Initialize the Skill when the initialization script is available.
4. Implement and test deterministic scripts.
5. Keep SKILL.md concise and route to references as needed.
6. Validate and package as `skill.zip`.

## Existing Skill update

1. Inspect the full current bundle.
2. Identify the requested change and compatibility implications.
3. Preserve valid structures and resources.
4. Update all affected files.
5. Validate the whole bundle.
6. Repackage the complete updated bundle as `skill.zip`.

## ZIP intake

1. Count `SKILL.md` entrypoints.
2. Reject multi-skill archives for this flow.
3. Validate a single Skill.
4. Stop on validation errors.
5. Return the validated archive as `skill.zip`.
