# Editor e Humanizador de Emails

## Propósito

`edit-humanize-emails` transforma notas, tópicos ou rascunhos em emails claros, concisos, profissionais e naturais. A Skill corrige erros, preserva factos, adapta o tom e pede informação adicional apenas quando uma lacuna puder mudar materialmente a mensagem.

## Plataforma suportada

- ChatGPT/OpenAI

## Estrutura

```text
edit-humanize-emails/
├── SKILL.md
├── README.md
├── CHANGELOG.md
├── agents/
│   └── openai.yaml
└── tests/
    ├── should-trigger.md
    ├── should-not-trigger.md
    └── edge-cases.md
```

Não existem `scripts/`, `references/` ou `assets`: a transformação é linguística e não requer automação, documentação externa ou templates estáticos.

## Instalação

1. Rever o conteúdo da pasta e ajustar regras de voz próprias, caso existam.
2. Carregar o ZIP na área de gestão de Skills compatível com ChatGPT/OpenAI ou copiar a pasta completa para o repositório privado onde as Skills são mantidas.
3. Confirmar que a pasta continua a chamar-se `edit-humanize-emails` e que `SKILL.md` permanece na raiz.
4. Executar os prompts de teste antes de usar a Skill com mensagens reais.

## Exemplos de prompts

1. `Transforma estas notas num email curto para o fornecedor. Quero um tom cordial, mas firme: a entrega voltou a atrasar e preciso de uma nova data confirmada.`
2. `Revê este email em português de Portugal. Corrige os erros e torna-o mais humano, sem mudar o que estou a pedir: [rascunho].`
3. `Write a concise email in English from these bullets. Ask me first if any essential context is missing: [bullets].`

## Dependências

Nenhuma. A Skill não usa conectores, APIs, scripts nem serviços externos.

## Limitações conhecidas

- Não envia emails nem acede ao Gmail, Outlook ou contactos.
- Não valida a exatidão jurídica, médica, financeira ou laboral do conteúdo.
- A qualidade do tom depende do contexto disponível sobre o destinatário e a relação.
- Não deve inventar informação quando o input está incompleto.

## Versão

`0.2.0`

## Última atualização

23 de setembro de 2026
