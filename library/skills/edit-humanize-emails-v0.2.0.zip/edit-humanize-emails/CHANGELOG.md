# Changelog

## [0.2.0] - 2026-09-23

### Added

- Triagem de informação em falta e até três perguntas objetivas quando uma lacuna é material.
- Gestão explícita de incerteza, placeholders e interpretações alternativas.
- Testes de ativação, não ativação e casos-limite.
- Metadata para ChatGPT/OpenAI e documentação de instalação.

### Changed

- Estrutura adaptativa: texto corrido para emails simples e bullets apenas quando melhoram a leitura.
- Humanização convertida em critérios verificáveis de voz, ritmo, formalidade e fidelidade ao utilizador.
- Formato de saída reduzido ao email pronto a copiar, salvo pedido de análise ou alternativas.

## [0.1.0] - 2026-09-23

### Added

- Versão inicial baseada nas instruções de edição de emails fornecidas pelo utilizador.
- Redação em português europeu e inglês, com foco em clareza, concisão e organização.
