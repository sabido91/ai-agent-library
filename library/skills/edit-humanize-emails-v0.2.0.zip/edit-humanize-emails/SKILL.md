---
name: edit-humanize-emails
description: Redige, corrige, encurta e humaniza emails a partir de notas, tópicos ou rascunhos, em português europeu ou inglês. Usar quando o utilizador pedir para escrever, melhorar, rever, traduzir ou tornar um email mais claro, natural, profissional, diplomático, firme ou conciso. Antes de redigir, identifica lacunas que alterem materialmente a mensagem e faz até três perguntas objetivas quando necessário. Não usar para campanhas de marketing em massa, mensagens instantâneas, relatórios, aconselhamento jurídico ou envio automático de emails.
---

# Objetivo

Transformar notas, tópicos, comentários ou rascunhos em emails prontos a enviar, corretos, claros, concisos e humanos, preservando os factos e a intenção do utilizador.

Criar um email eficaz, não um relatório. Privilegiar a mensagem principal, a relação com o destinatário e a ação esperada.

# Quando usar

- Redigir um email a partir de informação desorganizada.
- Rever gramática, ortografia, clareza, estrutura ou tom.
- Encurtar um email longo sem perder conteúdo importante.
- Tornar um texto mais natural, cordial, diplomático, firme ou executivo.
- Adaptar ou traduzir um email entre português europeu e inglês profissional natural.
- Organizar feedback, decisões, pedidos ou próximos passos num email.

# Quando não usar

- Criar campanhas de email marketing, newsletters ou sequências comerciais em massa.
- Escrever mensagens para chat, redes sociais, relatórios ou atas sem componente de email.
- Enviar emails, aceder a caixas de correio ou gerir contactos.
- Inventar argumentos jurídicos, compromissos, aprovações, prazos ou factos ausentes.
- Dissimular fraude, assédio, manipulação ou identidade falsa.

# Inputs esperados

Aceitar um ou mais dos seguintes elementos:

- notas, tópicos ou rascunho existente;
- objetivo do email;
- destinatário e relação com o remetente;
- resultado ou ação pretendida;
- idioma, tom e nível de formalidade;
- nomes, datas, prazos e outros factos que devam ser preservados;
- contexto anterior relevante, incluindo excertos de uma thread.

Não exigir todos os elementos. Distinguir entre lacunas críticas e preferências opcionais.

# Workflow

1. **Interpretar o pedido.** Identificar mensagem central, destinatário, objetivo, idioma, tom, factos, decisão ou ação esperada.
2. **Avaliar lacunas.** Considerar crítica apenas a informação cuja ausência possa mudar materialmente o sentido, o compromisso, o destinatário, o prazo ou a ação pedida.
3. **Decidir se é necessário perguntar.**
   - Fazer até três perguntas curtas e agrupadas quando houver lacunas críticas.
   - Não perguntar por detalhes opcionais que possam ser resolvidos de forma prudente.
   - Se o utilizador pedir uma versão imediata, redigir com marcadores entre parênteses retos, como `[Nome]` ou `[data]`, em vez de inventar.
4. **Limpar o input.** Remover repetições, ruído visual, cabeçalhos de thread irrelevantes, notas duplicadas e emojis decorativos. Preservar marcas, produtos, claims, citações aprovadas, nomes, datas e decisões.
5. **Organizar a mensagem.** Colocar o objetivo e a informação principal no início. Agrupar por temas apenas quando isso facilitar a leitura; não seguir automaticamente a ordem bruta das notas.
6. **Redigir na voz adequada.** Manter a intenção e, quando reconhecível, a voz do utilizador. Ajustar cordialidade, firmeza e formalidade à relação com o destinatário, sem fabricar intimidade.
7. **Escolher a estrutura mínima eficaz.** Usar texto corrido em emails simples. Usar bullets ou pequenos subtítulos apenas quando existirem vários pontos, decisões ou ações que beneficiem de leitura rápida.
8. **Tornar a ação explícita.** Incluir um pedido, decisão ou próximo passo claro quando o email exigir resposta. Não inventar responsável ou prazo.
9. **Humanizar.** Substituir linguagem artificial, cerimoniosa ou genérica por formulações naturais; variar o ritmo sem ornamentar; evitar chavões corporativos, exageros, adjetivos vazios e frases típicas de texto automático.
10. **Rever silenciosamente.** Verificar correção, concisão, coerência, tom, fidelidade factual, clareza do assunto e do pedido final. Reduzir tudo o que não ajude o destinatário a compreender ou agir.

# Formato de output

Quando faltar informação crítica, entregar apenas as perguntas necessárias, numeradas e em linguagem simples.

Quando houver informação suficiente, entregar por defeito:

```markdown
Assunto: [assunto específico]

[Saudação adequada],

[Corpo do email]

[Fecho adequado]
```

Usar `Subject:` em inglês. Entregar apenas o email pronto a copiar, salvo se o utilizador pedir alternativas, explicações ou análise das alterações.

Se o email for simples, manter dois a quatro parágrafos curtos. Para conteúdo complexo, usar no máximo os subtítulos e bullets necessários. Não transformar o corpo num documento em Markdown pesado.

Quando o utilizador pedir opções, apresentar no máximo três versões claramente diferenciadas por tom ou extensão.

# Regras de qualidade

- Escrever em português europeu quando o pedido estiver em português, salvo indicação contrária.
- Responder no idioma do email ou no idioma explicitamente pedido; não traduzir automaticamente.
- Criar sempre um assunto específico, exceto quando o utilizador pedir apenas um excerto ou resposta dentro de uma thread cujo assunto deva ser mantido.
- Colocar a informação mais importante nas primeiras frases.
- Usar voz ativa, frases claras e vocabulário natural.
- Preferir uma ideia por frase ou bullet.
- Manter o grau de firmeza pedido sem tornar o texto agressivo.
- Corrigir erros sem alterar factos, compromissos ou intenção.
- Evitar fórmulas como "Espero que este email o encontre bem" quando não combinarem com a voz ou o contexto.
- Evitar excesso de agradecimentos, introduções cerimoniosas, conclusões repetitivas e linguagem de relatório.
- Não usar etiquetas como `[URGENTE]` ou `[AÇÃO NECESSÁRIA]` sem justificação no contexto.
- Não explicar que o texto foi "humanizado"; demonstrá-lo na redação.

# Gestão de incerteza

- Perguntar apenas quando a resposta puder alterar materialmente o email.
- Limitar a primeira ronda a três perguntas; combinar perguntas relacionadas.
- Assinalar placeholders de forma visível quando o utilizador preferir avançar sem responder.
- Preservar formulações ambíguas deliberadas se o utilizador não autorizar maior precisão.
- Quando houver duas interpretações plausíveis com consequências diferentes, expô-las brevemente e pedir escolha.
- Não apresentar inferências como factos.

# Limites e segurança

- Não inventar nomes, datas, valores, decisões, aprovações, anexos, responsáveis ou prazos.
- Não prometer o envio, receção ou acompanhamento de emails.
- Não expor dados pessoais presentes em threads além do necessário para a versão final.
- Recusar assistência destinada a fraude, phishing, assédio, coerção ou representação enganosa.
- Em temas jurídicos, médicos, financeiros ou laborais sensíveis, melhorar a redação sem validar a exatidão técnica; recomendar confirmação especializada quando o risco for material.
- Não incluir comentários internos, instruções do utilizador ou conteúdo confidencial no email final sem intenção clara.
