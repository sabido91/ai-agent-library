# Casos em que a Skill deve ser ativada

## Caso 1: notas soltas para fornecedor

**Prompt**

> Faz um email ao fornecedor com estas notas: terceira entrega atrasada; precisamos do material antes de sexta; pedir nova data realista; tom firme sem ser agressivo.

**Ativação esperada:** Sim.

**Comportamento esperado:** Identificar que falta saber a sexta-feira relevante se a data não estiver implícita no contexto e perguntar apenas se isso for material; depois criar um assunto específico e um email curto com pedido claro.

**Critérios de qualidade:** Tom firme e cordial, sem inventar datas, dois a quatro parágrafos e CTA inequívoco.

## Caso 2: revisão e humanização

**Prompt**

> Corrige e humaniza este email, mantendo o meu tom direto: "Exmos. Senhores, pela presente venho solicitar que procedam ao envio da versão revista com a maior brevidade possível..."

**Ativação esperada:** Sim.

**Comportamento esperado:** Simplificar a formulação, corrigir o texto e preservar o pedido sem fazer perguntas desnecessárias.

**Critérios de qualidade:** Português europeu natural, menor formalidade, mesma intenção e ausência de comentários sobre o processo.

## Caso 3: email em inglês

**Prompt**

> Write a short email in English to the project team. The launch was approved, but we still need final legal validation. Ask them to confirm by Thursday.

**Ativação esperada:** Sim.

**Comportamento esperado:** Produzir assunto e corpo em inglês profissional natural, com a aprovação e a validação ainda pendente claramente separadas.

**Critérios de qualidade:** Não confundir aprovação de lançamento com validação jurídica; CTA e prazo claros; linguagem concisa.

## Caso 4: tradução com adaptação

**Prompt**

> Passa este email para inglês e torna-o mais diplomático, sem suavizar o prazo: [rascunho].

**Ativação esperada:** Sim.

**Comportamento esperado:** Traduzir e adaptar o registo, preservando integralmente o prazo e o pedido.

**Critérios de qualidade:** Inglês idiomático, diplomacia sem ambiguidade e fidelidade factual.
