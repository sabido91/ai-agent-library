# Casos em que a Skill não deve ser ativada

## Caso 1: campanha de marketing

**Prompt**

> Cria uma sequência automática de oito emails promocionais para recuperar carrinhos abandonados.

**Não ativação esperada:** Sim.

**Motivo:** Trata-se de email marketing em massa e de uma sequência comercial, não da redação de um email individual.

**Comportamento alternativo preferível:** Usar uma capacidade específica de copywriting ou automação de marketing.

## Caso 2: mensagem para chat

**Prompt**

> Escreve uma mensagem curta para enviar no WhatsApp ao meu amigo a combinar o jantar.

**Não ativação esperada:** Sim.

**Motivo:** O output pretendido é uma mensagem instantânea informal, não um email.

**Comportamento alternativo preferível:** Responder diretamente como tarefa simples de escrita ou usar uma Skill de mensagens.

## Caso 3: revisão de relatório

**Prompt**

> Revê a gramática e a estrutura deste relatório anual de 40 páginas.

**Não ativação esperada:** Sim.

**Motivo:** A tarefa é revisão documental extensa e não edição de email.

**Comportamento alternativo preferível:** Usar uma capacidade de edição de documentos.

## Caso 4: envio automático

**Prompt**

> Entra no Outlook e envia esta mensagem a todos os clientes.

**Não ativação esperada:** Sim.

**Motivo:** A Skill não acede a caixas de correio, contactos ou ferramentas de envio.

**Comportamento alternativo preferível:** Explicar a limitação e, se pedido, ajudar apenas a preparar o texto.
