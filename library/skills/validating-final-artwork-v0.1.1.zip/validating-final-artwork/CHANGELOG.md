# Changelog

## [0.1.1] - 2026-09-18

### Changed

- Restringidos os inputs suportados a PDF e PNG.
- Clarificado que as duas versões podem combinar PDF e PNG quando a correspondência entre conteúdos for inequívoca.
- Passou a ser exigida uma exportação para PDF ou PNG quando o ficheiro de origem estiver noutro formato.

## [0.1.0] - 2026-09-18

### Added

- Versão inicial da Skill para comparar artes finais antigas e novas.
- Validação individual das alterações pedidas.
- Revisão obrigatória de linguagem, ortografia, informação, cores aparentes e composição visual.
- Deteção de alterações inesperadas fora do âmbito do pedido.
- Estados globais `APROVADO`, `REPROVADO` e `NÃO VERIFICÁVEL`.
- Checklist de revisão, metadata GPT/OpenAI e testes comportamentais.
