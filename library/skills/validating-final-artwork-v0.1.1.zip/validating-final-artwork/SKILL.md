---
name: validating-final-artwork
description: Compara uma arte final anterior com uma nova versão, em PDF ou PNG, e com a lista de alterações pedidas, confirmando se cada pedido foi implementado, revendo obrigatoriamente linguagem, ortografia, cores, informação e consistência visual, e detetando alterações inesperadas. Usar em pedidos como "valida esta nova arte final", "confirma se as correções foram aplicadas" ou "compara estas duas versões e verifica se nada mais mudou". Não usar para criar ou redesenhar artes, editar ficheiros, aceitar outros formatos sem exportação para PDF ou PNG, aprovar tecnicamente impressão sem dados de pré-impressão, nem comparar versões sem acesso visual suficiente aos ficheiros.
---

# Validating Final Artwork

## Objetivo

Avaliar uma nova arte final contra a versão anterior e as alterações pedidas. Só aprovar quando os pedidos estiverem corretamente implementados, a nova versão passar a revisão global e não existirem alterações inesperadas.

## Quando usar

- Comparar uma arte final antiga com uma nova.
- Validar uma lista de correções ou alterações solicitadas.
- Fazer controlo final de conteúdo, linguagem e consistência visual.
- Confirmar que elementos fora do âmbito do pedido permaneceram inalterados.

## Quando não usar

- Criar, redesenhar ou editar a arte final.
- Comparar apenas descrições textuais sem acesso às duas versões visuais.
- Certificar requisitos técnicos de impressão que não estejam visíveis ou disponíveis em metadata verificável, como separações, tintas diretas, perfis ICC, fontes incorporadas, sangria ou resolução efetiva.
- Substituir revisão legal, regulamentar ou de marca especializada.

## Inputs esperados

Exigir:

1. Arte final anterior, identificada como `ANTIGA`.
2. Nova arte final, identificada como `NOVA`.
3. Lista das alterações pedidas, mesmo que indique explicitamente que não houve pedidos.

Aceitar exclusivamente PDF ou PNG. A arte antiga e a nova podem usar formatos diferentes entre estas duas opções, desde que representem o mesmo conteúdo e seja possível estabelecer uma correspondência inequívoca. Para qualquer outro formato, pedir uma exportação visual fiel em PDF ou PNG antes de validar. Pedir apenas a informação em falta que impeça uma conclusão fiável, como correspondência entre páginas, idioma pretendido ou texto ilegível.

## Workflow

1. **Validar os inputs.** Confirmar que existem duas versões distinguíveis e uma lista de pedidos. Identificar páginas, faces, variantes, idiomas e diferenças de dimensão ou orientação. Não iniciar uma comparação conclusiva se a correspondência entre versões for ambígua.
2. **Avaliar a legibilidade.** Verificar se texto, detalhes e cores são suficientemente visíveis. Assinalar como `NÃO VERIFICÁVEL` qualquer zona que não possa ser inspecionada com confiança; nunca adivinhar conteúdo oculto, cortado ou desfocado.
3. **Criar a matriz de alterações pedidas.** Separar cada pedido num item verificável e registar o resultado como `IMPLEMENTADO`, `PARCIAL`, `NÃO IMPLEMENTADO` ou `NÃO VERIFICÁVEL`.
4. **Comparar cada pedido.** Localizar o elemento na versão antiga e na nova, confirmar a alteração concreta e verificar se a implementação introduziu erros colaterais.
5. **Rever obrigatoriamente a linguagem da nova arte.** Ler todo o texto visível, incluindo títulos, corpo, rodapés, legendas, chamadas, datas, preços, unidades, contactos, avisos e texto legal. Verificar ortografia, gramática, concordância, pontuação, capitalização, acentuação, espaços, quebras, hifenização, duplicações e texto truncado. Respeitar nomes próprios, marcas, códigos e grafias deliberadas; quando houver dúvida, reportar como possível erro e indicar a incerteza.
6. **Rever a nova arte globalmente.** Aplicar a checklist de [revisão de arte final](references/artwork-review-checklist.md). Verificar informação, coerência interna, cores aparentes, contraste, alinhamento, hierarquia, consistência, elementos em falta, sobreposições, cortes e legibilidade. Distinguir inspeção visual de validação técnica de pré-impressão.
7. **Detetar alterações inesperadas.** Comparar todos os elementos visíveis que não constam dos pedidos: texto, números, imagens, logótipos, ícones, cores, posições, tamanhos, espaçamentos, fundos, margens e composição. Ignorar apenas diferenças de renderização sem efeito no conteúdo, como compressão ou antialiasing; indicar essa interpretação quando relevante.
8. **Determinar o estado final.** Usar `APROVADO` apenas se todos os pedidos estiverem implementados, a revisão global não encontrar problemas e não houver alterações inesperadas. Usar `REPROVADO` se existir qualquer problema confirmado. Usar `NÃO VERIFICÁVEL` se uma limitação impedir uma conclusão segura.
9. **Emitir o check.** Ser conciso quando estiver tudo correto. Se houver problemas, listar cada um com localização e evidência suficiente para permitir a correção.

## Formato de output

Começar sempre pelo estado global:

```markdown
# Resultado: APROVADO | REPROVADO | NÃO VERIFICÁVEL

## Check
- Alterações pedidas: OK | PROBLEMA | NÃO VERIFICÁVEL
- Linguagem e ortografia: OK | PROBLEMA | NÃO VERIFICÁVEL
- Informação e consistência visual: OK | PROBLEMA | NÃO VERIFICÁVEL
- Alterações inesperadas: NÃO DETETADAS | DETETADAS | NÃO VERIFICÁVEL
```

Se o resultado for `APROVADO`, acrescentar apenas uma conclusão curta. Se for `REPROVADO` ou `NÃO VERIFICÁVEL`, acrescentar:

```markdown
## Problemas encontrados

| # | Categoria | Localização | Problema | Evidência | Correção esperada |
|---|-----------|-------------|----------|----------|-------------------|
| 1 | Alteração pedida / Linguagem / Informação / Visual / Alteração inesperada | Página, face ou zona | Descrição objetiva | Antiga, nova e/ou pedido relevante | Ação concreta |

## Alterações pedidas

| Pedido | Estado | Evidência |
|--------|--------|----------|
| ... | IMPLEMENTADO / PARCIAL / NÃO IMPLEMENTADO / NÃO VERIFICÁVEL | ... |

## Limitações
- Indicar apenas limitações que afetem a conclusão.
```

Não declarar que um problema não existe quando a zona correspondente não foi verificável.

## Regras de qualidade

- Basear cada conclusão em conteúdo observável nas duas versões e no pedido.
- Rever sempre a linguagem, mesmo que o utilizador não a mencione.
- Fazer a comparação nos dois sentidos: confirmar o que devia mudar e confirmar o que devia permanecer.
- Dar localização específica por página, face, painel ou zona visual.
- Separar erros confirmados de suspeitas e limitações.
- Não reprovar por diferenças puramente técnicas de renderização sem impacto visual ou informativo.
- Não suavizar o estado final: qualquer problema confirmado implica `REPROVADO`.
- Manter o relatório curto, acionável e sem reescrever todo o conteúdo correto.

## Gestão de incerteza

- Pedir nova exportação ou imagem de maior resolução quando a leitura não for fiável.
- Se o idioma ou variante linguística não estiverem definidos, inferir apenas quando houver evidência clara; caso contrário, pedir confirmação ou declarar a assunção.
- Classificar como `NÃO VERIFICÁVEL` apenas o ponto afetado e elevar o resultado global para `NÃO VERIFICÁVEL` quando esse ponto for necessário para aprovar.
- Usar expressões como `possível erro` quando uma grafia possa ser nome próprio, marca, termo técnico ou escolha editorial.

## Limites e segurança

- Não inventar texto, requisitos, especificações de marca ou critérios de impressão.
- Não expor informação sensível presente nos ficheiros além do necessário para identificar o problema.
- Não afirmar equivalência colorimétrica a partir de uma simples visualização no ecrã.
- Não afirmar aprovação técnica para produção quando não forem verificáveis ficheiro, resolução, sangria, perfis, separações, fontes e restantes requisitos de pré-impressão.
- Não alterar nem publicar os ficheiros recebidos.

## Referências e recursos

- Consultar [references/artwork-review-checklist.md](references/artwork-review-checklist.md) durante a revisão global e a deteção de alterações inesperadas.
