# Validação de Artes Finais

## Propósito

`validating-final-artwork` ajuda o GPT a comparar uma arte final anterior com uma nova versão e a lista de alterações pedidas. Confirma a implementação dos pedidos, faz uma revisão obrigatória de linguagem e qualidade global e deteta alterações inesperadas.

## Plataforma suportada

- GPT/OpenAI

## Estrutura

```text
validating-final-artwork/
├── SKILL.md
├── README.md
├── CHANGELOG.md
├── agents/
│   └── openai.yaml
├── references/
│   └── artwork-review-checklist.md
└── tests/
    ├── should-trigger.md
    ├── should-not-trigger.md
    └── edge-cases.md
```

`references/` contém a checklist detalhada necessária para tornar consistente a revisão linguística, informativa, visual e de alterações inesperadas. Não são necessários scripts nem assets: a inspeção depende da leitura multimodal dos ficheiros enviados.

## Instalação

1. Rever o conteúdo da pasta da Skill.
2. Copiar a pasta `validating-final-artwork` para o repositório privado de Skills GPT/OpenAI.
3. Disponibilizar a Skill no ambiente GPT/OpenAI segundo o processo interno aplicável.
4. Testar com duas artes de controlo e uma lista conhecida de alterações antes do uso em produção.

## Exemplos de prompts

1. `Compara a arte antiga e a nova. Confirma estas três alterações, revê a ortografia de todo o conteúdo e verifica se nada mais mudou.`
2. `Valida esta nova embalagem contra a versão aprovada. As alterações pedidas foram o preço e a data da campanha. Indica apenas se está aprovada ou quais são os problemas.`
3. `Faz o controlo final destes dois PDFs. Confirma as correções listadas, procura gralhas e deteta qualquer alteração inesperada em texto, cores, imagens ou composição.`

## Dependências

- Um GPT com capacidade para abrir e inspecionar visualmente ficheiros PDF e PNG.
- Arte anterior, arte nova e lista de alterações pedidas.
- Se a origem estiver noutro formato, uma exportação visual fiel para PDF ou PNG antes da validação.

Não existem dependências de código nem conectores externos.

## Limitações conhecidas

- A comparação visual não certifica por si só propriedades técnicas de pré-impressão, como perfis ICC, separações, sobreimpressão, sangria, fontes incorporadas ou resolução efetiva.
- Ficheiros desfocados, incompletos ou com escalas muito diferentes podem impedir uma conclusão segura.
- A equivalência colorimétrica não pode ser garantida apenas pela visualização no ecrã.
- A Skill assinala incerteza em nomes próprios, marcas ou linguagem técnica que não consiga validar com segurança.

## Versão

- Versão atual: `0.1.1`
- Última atualização: `2026-09-18`
