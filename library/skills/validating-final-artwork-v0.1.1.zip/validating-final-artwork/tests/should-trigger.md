# Casos em que a Skill deve ser ativada

## Caso 1 — Correções numa embalagem

**Prompt:** `Aqui estão a embalagem antiga, a nova e os pedidos: corrigir "disponivel" para "disponível" e mudar 250 g para 300 g. Valida a nova arte.`

**Ativação esperada:** Sim.

**Comportamento esperado:** Comparar as versões, validar separadamente os dois pedidos, rever todo o texto e a composição da nova arte e procurar mudanças não pedidas.

**Critérios de qualidade:** Estado global inequívoco; localização e evidência para cada problema; aprovação apenas se todos os checks passarem.

## Caso 2 — Campanha com alteração limitada

**Prompt:** `Compara estes dois PDFs. Na nova versão só devia mudar a data da campanha. Confirma que foi alterada e que tudo o resto está igual.`

**Ativação esperada:** Sim.

**Comportamento esperado:** Confirmar a data, rever linguagem e conteúdo global e comparar todos os elementos fora da data.

**Critérios de qualidade:** Detetar qualquer mudança adicional; não tratar diferenças de rasterização sem impacto como alteração inesperada.

## Caso 3 — Controlo final antes de aprovação

**Prompt:** `Faz um check final entre a arte antiga e a nova com base nesta lista de correções. Procura também erros ortográficos e diz-me se posso aprovar.`

**Ativação esperada:** Sim.

**Comportamento esperado:** Executar o workflow completo e devolver `APROVADO`, `REPROVADO` ou `NÃO VERIFICÁVEL`.

**Critérios de qualidade:** Rever obrigatoriamente todo o texto visível, verificar informação e composição e apresentar problemas de forma acionável.

## Caso 4 — Alterações em imagens e cores

**Prompt:** `A fotografia e a cor do título deviam ter mudado nesta nova arte. Verifica a implementação e confirma que texto, logótipo e restantes cores não foram mexidos.`

**Ativação esperada:** Sim.

**Comportamento esperado:** Comparar os elementos pedidos e verificar os restantes elementos visíveis, incluindo a linguagem.

**Critérios de qualidade:** Distinguir comparação visual de validação colorimétrica técnica e explicitar qualquer limitação.
