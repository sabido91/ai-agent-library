---
name: product-benchmark-research
description: Pesquisar, recolher, auditar e analisar benchmarks de produtos FMCG com base factual rastreável até à fonte, sobretudo em alimentação, bebidas, nutrição conveniente e snacking. Usar para benchmark de categoria, mapeamento de concorrência, scouting de inovação, comparação de formatos/embalagens, ingredientes, nutrição, claims, preço, conservação, referências internacionais e identificação de offer gaps. Não usar para inferir necessidades, preferência ou aceitação do consumidor; nesses casos recorrer a social listening ou research qualitativo. Produzir outputs em PT-PT, preservando ingredientes e claims no idioma original do rótulo.
---

# Product Benchmark Research

## Missão

Construir benchmarks FMCG factuais, auditáveis e rastreáveis, evitando alucinações, mistura de SKUs e generalizações indevidas.

Separar sempre:
1. factos de produto;
2. observações comerciais pontuais;
3. inspiração internacional;
4. offer gaps;
5. hipóteses estratégicas.

Responder em PT-PT. Manter ingredientes e claims no idioma original do rótulo; colocar traduções apenas em campo separado.

## Fronteiras da skill

- Nunca usar a oferta observada para concluir o que os consumidores precisam, preferem ou aceitam.
- Identificar apenas **offer gaps**; nunca declarar **consumer need gaps** a partir do benchmark.
- Nunca declarar sozinho um **strategic white space**. Tratar white space como interseção de need gap + offer gap + credibilidade da marca + viabilidade técnica + viabilidade económica.
- Encaminhar investigação de necessidades/linguagem do consumidor para `social-listening-strategist` ou research qualitativo quando aplicável.

## Realidade de acesso

- Tratar fotografia atual do rótulo/embalagem fornecida pelo utilizador como fonte de nível 1.
- Sem foto, assumir que a página oficial da marca é o teto realista de verificação online.
- Quando só existir retalhista, marcar o campo como `Secondary-only`.
- Nunca alegar verificação presencial ou laboratorial.
- Se um site recusar acesso, não contornar; registar e procurar outra fonte.
- Auditar por defeito 8–15 SKUs. Se a shortlist ultrapassar 15 SKUs, parar no gate da shortlist e pedir aprovação ao utilizador.

## Princípios obrigatórios

### Identidade do SKU

- Aplicar `1 linha = 1 SKU`.
- Definir SKU como: Marca + Produto + Variante/Sabor + Mercado validado + Formato de embalagem + Tamanho exato.
- Nunca fundir mercados, variantes, tamanhos ou versões de embalagem.

### Integridade dos dados

- Se um atributo não estiver na fonte, usar `Unknown`; nunca inferir.
- Separar facto observado, cálculo, interpretação e hipótese.
- Associar a cada campo material a fonte direta e a data de acesso `DD/MM/AAAA`.

### Evidência comercial

- Não usar e-commerce como prova de preferência, satisfação ou aceitação.
- Não tratar preço de um retalhista como preço médio ou preço de mercado.
- Não converter moeda implicitamente. Conversões para EUR exigem taxa, data, fonte BCE e coluna própria.
- Não afirmar presença em Portugal sem fonte situada em Portugal e verificada.
- Não equiparar listagem online a distribuição nacional ou presença física.

### Rótulo e processamento

- Não equiparar `100% Fruta` a `Sem Açúcares Adicionados`, `Baixo teor de açúcares`, `Alto teor em fibra` ou equivalência a fruta inteira.
- Não inferir UHT, Hot-Fill ou HPP a partir de conservação ambiente/refrigerada.
- Tratar `prensado a frio` e `HPP` como conceitos distintos.

## Hierarquia de fontes

Aplicar esta ordem:
1. foto atual do rótulo/embalagem fornecida pelo utilizador;
2. página oficial da marca no mercado;
3. página oficial do retalhista no mercado;
4. ficha técnica do distribuidor/importador oficial;
5. bases colaborativas, apenas como apoio;
6. imprensa, blogs, marketplaces e agregadores, apenas para descoberta/contexto.

Resolver divergências assim:
- rótulo atual do mercado correto prevalece sobre página da marca;
- marca prevalece sobre retalhista para composição;
- preço vem apenas de retalhista ou loja oficial no mercado pretendido;
- níveis 5–6 nunca verificam nutrição nem claims;
- registar sempre divergências materiais no `Registo de Conflitos`.

## Estados de validação

### Campo
- `Verified`: fonte nível 1–2 no mercado correto, com URL e data.
- `Secondary-only`: apenas fonte nível 3–5.
- `Conflicting`: fontes divergem e hierarquia não resolve.
- `Unknown`: dado não encontrado.

### Linha
Aplicar o estado crítico mais restritivo:
`Conflicting > Unknown > Partially verified > Verified`.

Campos críticos: identidade, mercado, formato/tamanho, conservação, ingredientes, nutrição e claims. Avaliar preço separadamente.

### Pesquisa
- `Discovery only`
- `Confirmed candidate`
- `Validated SKU`
- `International inspiration`
- `Not comparable`

Excluir `Discovery only` e `Not comparable` da tabela final comparativa.

## Workflow obrigatório

### Fase 0 — Pergunta estratégica e scope [Utilizador]
1. Definir a decisão que o benchmark fundamenta.
2. Definir categorias, mercados, formatos e critérios de inclusão/exclusão.
3. Pedir fotos de rótulos dos SKUs críticos, se existirem.

Se estes elementos já estiverem claros no pedido, não repetir perguntas.

### Fase 1 — Mapa de categorias e gaps [Auto]
Construir eixos de análise antes da pesquisa: formato, conservação, ocasião, ingrediente-âncora, claim e preço. Registar offer gaps a explorar.

### Fase 2 — Descoberta [Auto]
Construir longlist em `Discovery only`; permitir fontes nível 5–6 apenas nesta fase.

### Fase 3 — Verificação de identidade [Auto]
Confirmar SKU ativo, único, mercado, variante, tamanho e pack.

### Fase 4 — Shortlist [Utilizador]
Selecionar por defeito 8–15 SKUs, evitar quase-duplicados e apresentar razão de inclusão. Parar para aprovação se >15.

### Fase 5 — Formulação, nutrição, claims e conservação [Auto]
Auditar campo a campo. Transcrever sem resumir, traduzir ou inferir os valores-fonte.

### Fase 6 — Preço e disponibilidade [Auto]
Registar retalhista, canal, moeda, tipo de preço, base da oferta e data.

### Fase 7 — Normalização e cálculos [Auto]
Calcular por código ou fórmula; nunca à mão. Comparar ml com ml e g com g. Não assumir densidade 1 g/ml.

### Fase 8 — Conflitos [Auto]
Aplicar hierarquia de fontes, registar conflitos e rebaixar estados quando necessário. Nunca escolher arbitrariamente uma fonte para limpar a tabela.

### Fase 9 — Análise e síntese [Auto]
Responder à pergunta da Fase 0 mantendo separação entre factos, observações comerciais, interpretações e hipóteses.

## Cálculos obrigatórios

- `valor_por_porção = valor_por_100 × (tamanho_da_porção / 100)`
- `preço_por_100_local = (preço_observado / tamanho_da_embalagem) × 100`
- Multipacks: derivar preço unitário explicitamente e registar a base.
- Promoções: guardar preço promocional e preço regular separadamente.
- Moeda estrangeira: calcular primeiro na moeda local; EUR é opcional, com BCE + taxa + data.
- Arredondar nutrição a 1 casa decimal e valores monetários a 2 casas decimais.

## Regras por campo

- Um mercado por linha; nunca `PT/ES`.
- Usar apenas a taxonomia fechada de `pack_type` definida em `references/data-model-and-templates.md`.
- Copiar conservação literal da fonte; não inferir pela secção de loja.
- Copiar ingredientes integrais no idioma original.
- Copiar claims literalmente do rótulo; não converter copy de site em claim de rótulo.
- Usar apenas nutrição declarada; nunca estimar em falta.
- Registar teor de fruta/vegetais apenas quando percentagem é declarada.
- Separar açúcares totais de claims de não adição.
- Classificar `fonte de`/`alto teor` em fibra/proteína apenas se o claim estiver declarado.
- Registar preço bruto praticado; RRP não equivale a preço praticado.
- Registar tecnologia de processamento apenas quando declarada literalmente.

## Pesquisa internacional

- Usar apenas como inspiração de conceito, arquitetura, formato, ingredientes e rotulagem.
- Nunca inferir preço, adesão ou distribuição em Portugal com base internacional.
- Manter uma linha por mercado e a moeda local.
- Separar sempre `Mercado factual local (PT)` de `Benchmark de inspiração internacional`.

## Outputs

Produzir dois entregáveis quando o utilizador pedir benchmark completo:

1. **Folha de cálculo** com os separadores e campos definidos em `references/data-model-and-templates.md`.
2. **Documento de análise** com:
   - resposta curta à pergunta estratégica;
   - scope, fontes e teto de verificação;
   - mapa de categorias/ecossistema;
   - benchmark factual;
   - offer gaps;
   - implicações;
   - síntese `SABEMOS / SUGERE / NÃO DEMONSTRA / PRECISAMOS DE TESTAR`;
   - limitações obrigatórias.

Ler `references/data-model-and-templates.md` antes de construir tabelas, folhas de cálculo, templates de auditoria ou o output final completo.
Ler `references/limitations-and-checklist.md` antes de finalizar qualquer benchmark completo.

## Regra final de qualidade

Nunca apresentar um SKU como totalmente verificado apenas porque uma fonte o valida. A validação é sempre campo a campo, e o relatório deve declarar explicitamente o teto de verificação atingido.
