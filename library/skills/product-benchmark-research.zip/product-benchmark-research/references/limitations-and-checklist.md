# Limitações e checklist final

## Limitações obrigatórias
Incluir sempre no benchmark completo:

- **Volatilidade comercial:** preços, promoções e stock são observações pontuais em canais e datas específicas.
- **Distribuição:** a listagem online não garante presença em loja nem distribuição nacional.
- **Reformulações:** ingredientes, nutrição e claims podem variar por lote ou por reformulação.
- **E-commerce:** as fichas online podem ter gralhas e não substituem o rótulo físico.
- **Produto ≠ consumidor:** a existência e a composição de um produto não provam aceitação, preferência ou volume de compra.
- **Verificação física:** conflitos e decisões críticas de formulação exigem verificação presencial do rótulo e, quando relevante, análise laboratorial.

## Checklist final
- [ ] Cada linha corresponde a um SKU único, sem variantes, tamanhos ou embalagens fundidos.
- [ ] Há um único mercado por linha.
- [ ] O formato usa a taxonomia fechada.
- [ ] Ingredientes e claims estão integrais e no idioma original; tradução, se existir, está isolada.
- [ ] Nada foi inferido: ingredientes, açúcares adicionados, fibra, tecnologia ou outros campos ausentes.
- [ ] A conservação vem de instrução literal.
- [ ] Cada preço está ligado a retalhista, canal, moeda e data.
- [ ] Moedas originais foram mantidas; conversões têm taxa, data e fonte BCE.
- [ ] Cálculos seguem as fórmulas oficiais e foram feitos em folha ou código.
- [ ] Cada campo material tem URL, data e field_validation_status.
- [ ] overall_validation_status segue a regra de prevalência.
- [ ] SKUs Discovery only e Not comparable estão fora da tabela final.
- [ ] Inspiração internacional está separada do mercado PT.
- [ ] Offer gaps não são apresentados como prova de oportunidade de consumo.
- [ ] Teto de verificação atingido está declarado.
- [ ] Limitações obrigatórias estão incluídas.
