# Data model and templates

## Conteúdo
1. Estrutura de dados
2. Taxonomia de pack
3. Registos adicionais
4. Regras de cálculo especiais
5. Templates A–H
6. Estrutura dos outputs finais

## 1. Estrutura de dados

### A. SKU Master
- sku_id
- brand_name
- product_name
- variant_name
- validated_market
- pack_type
- pack_size_value
- pack_size_unit (ml/g)
- storage_before_opening (Ambiente / Refrigerado / Congelado / Conflicting)
- research_status
- overall_validation_status

### B. Formula & Nutrition
**Chave:** sku_id

Ingredientes e claims:
- ingredients_verbatim_full
- ingredients_key_components
- claims_verbatim
- claims_translation_pt

Nutrição por 100 ml/g:
- energy_kcal_100
- energy_kj_100
- fat_100
- saturates_100
- carbohydrate_100
- sugars_100
- fibre_100
- protein_100
- salt_100

Contexto:
- fruit_veg_content_pct (só quando declarado)
- processing_claim_verbatim

Fonte:
- product_source_url
- product_source_level (1–6)
- product_source_access_date

### C. Commercial Observations
- observation_id
- sku_id
- retailer_name
- sales_channel (Online Retail / Physical Store / Official Brand Store)
- observed_price
- currency
- price_type (Regular / Promotional / RRP)
- regular_price_if_promo
- pack_price_basis (Unidade avulsa / Unidade de multipack / Preço de multipack)
- availability_status (Listed-In stock / Out of stock / Unconfirmed)
- price_source_url
- price_source_access_date

### D. Calculated Comparison
**Chave:** sku_id

Preço:
- price_per_100_local

Porção:
- serving_size_value
- serving_size_source (rótulo, ou embalagem individual)
- energy_kcal_serving
- sugars_serving
- fibre_serving
- protein_serving

Conversão EUR, só quando aplicável:
- analytical_price_eur
- analytical_price_per_100_eur
- fx_rate_used
- fx_rate_date
- fx_source

## 2. Taxonomia fechada de pack_type
- Bottle PET
- Bottle HDPE
- Glass bottle
- Carton/Tetra Brik
- Tetra Prisma
- Pouch with spout
- Pouch without spout
- Cup/pot
- Can
- Sachet
- Multipack
- Other (descrever)

## 3. Registos adicionais
- Audit Log: estado de cada campo, com fonte.
- Registo de Conflitos.
- Campos pendentes: o que exige foto de rótulo ou visita a loja.
- Supporting Discovery: longlist com fontes de descoberta.

## 4. Casos especiais de cálculo
- **ml vs. g:** comparar ml com ml e g com g; nunca assumir densidade 1,0 g/ml.
- **Multipacks:** preço unitário = preço do pack / número de unidades; registar `pack_price_basis = Preço proporcional derivado de multipack` quando aplicável.
- **Promoções:** observed_price = promocional; regular_price_if_promo = preço regular.
- **Moeda estrangeira:** calcular primeiro na moeda original; EUR opcional com taxa BCE, data e fonte.
- **Arredondamento:** 1 casa decimal na nutrição e 2 casas nos valores monetários.

## 5. Templates

### Template A — Ficha de Descoberta
- Marca:
- Produto & Variante:
- Mercado de descoberta:
- Formato presumido:
- Offer gap que preenche:
- Razão de inclusão:
- URL de descoberta:
- Data (DD/MM/AAAA):
- Estado: Discovery only

### Template B — Verificação de Identidade
- SKU ID: SKU-XX
- Marca confirmada:
- Linha & variante exata (como no rótulo):
- Mercado de validação:
- Tamanho & unidade:
- Embalagem (taxonomia):
- Estado: Confirmed candidate

### Template C — Auditoria por Campo
| Campo | Valor registado | Nível da fonte (1–6) | URL | Evidência textual literal | Data | field_validation_status |
|---|---|---|---|---|---|---|

Campos mínimos:
- Nome & variante
- Mercado
- Formato & tamanho
- Conservação
- Ingredientes
- Claims
- Energia
- Açúcares
- Fibra
- Proteína
- Sal

### Template D — Observação Comercial
- SKU ID:
- Retalhista:
- Canal:
- Mercado / cidade:
- Preço observado:
- Moeda:
- Tipo de preço:
- Base da oferta:
- Preço por 100 ml/g (moeda local):
- URL:
- Data (DD/MM/AAAA):

### Template E — Registo de Conflito
- SKU ID:
- Campo:
- Fonte A (descrição + URL + data):
- Fonte B (descrição + URL + data):
- Impacto na comparabilidade:
- Ação corretiva (ex.: foto de rótulo em loja):
- Estado: Conflicting

### Template F — Offer Gap
- ID: GAP-XX
- Categoria / ocasião:
- Cobertura atual na base:
- O que sabemos (factual):
- O que falta saber:
- Tipos de SKU a procurar:
- Mercados prioritários:
- Risco de enviesamento:

### Template G — Tabela Final de Benchmark Factual
| SKU ID | Marca & Produto | Mercado | Tamanho & Formato | Conservação | Preço (moeda local) | Preço/100 | Açúcares/100 | Fibra/100 | Proteína/100 | overall_validation_status |
|---|---|---|---|---|---|---|---|---|---|---|

### Template H — Implicações Estratégicas
| Facto de produto | Observação comercial | Interpretação | Implicação para I&D/Inovação | Hipótese a validar com consumidor |
|---|---|---|---|---|

## 6. Outputs finais

### Folha de cálculo
Separadores:
- SKU Master
- Formula & Nutrition
- Commercial Observations
- Calculated Comparison
- Audit Log
- Conflitos
- Campos pendentes
- Discovery

### Documento de análise
1. Resposta curta à pergunta da Fase 0
2. Scope, fontes e teto de verificação atingido
3. Mapa de categorias e ecossistema de oferta
4. Tabela final de benchmark, separando PT de inspiração internacional
5. Offer gaps
6. Implicações
7. Síntese epistémica:
   - O que SABEMOS
   - O que SUGERE
   - O que NÃO DEMONSTRA
   - O que PRECISAMOS DE TESTAR
8. Limitações obrigatórias
