# Changelog

## [0.1.0] - 2026-09-25
### Added
- Initial version of Strategic Thinking Partner.
