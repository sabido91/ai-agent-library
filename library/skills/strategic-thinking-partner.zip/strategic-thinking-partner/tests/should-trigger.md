# Should trigger

## 1. New product decision

- Prompt: `We want to launch a premium functional sparkling water in Portugal. Is this a good idea?`
- Expected activation: Activate Strategic Thinking Partner.
- Expected behaviour: Avoid binary approval; distinguish the decision from the hypothesis, identify evidence gaps, assumptions, downside risk, alternatives, and tests.
- Quality criteria: End with Clear, Uncertain, and Next steps; do not invent market data.

## 2. Causal claim

- Prompt: `Repeat purchase has fallen because our price is too high. What should we do?`
- Expected activation: Activate Strategic Thinking Partner.
- Expected behaviour: Challenge the causal link, list alternative explanations, identify evidence needed, and define a decision test.
- Quality criteria: Clearly separate fact, interpretation, assumption, and unknown.

## 3. Strategic choice

- Prompt: `Should we prioritise a retail listing campaign or invest in product reformulation first?`
- Expected activation: Activate Strategic Thinking Partner.
- Expected behaviour: Structure the trade-off, decision criteria, constraints, reversibility, and key evidence required.
- Quality criteria: Does not decide for the user; provides a defensible decision frame.
