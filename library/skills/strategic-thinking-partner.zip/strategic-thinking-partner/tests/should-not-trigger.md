# Should not trigger

## 1. Simple rewrite

- Prompt: `Rewrite this email in more professional Portuguese.`
- Expected non-activation: Do not activate Strategic Thinking Partner.
- Reason: The request is editing, not critical strategic analysis.
- Preferred alternative behaviour: Rewrite the email directly.

## 2. Factual lookup

- Prompt: `What is the population of Lisbon?`
- Expected non-activation: Do not activate Strategic Thinking Partner.
- Reason: The request requires a factual lookup, not a reasoning partnership.
- Preferred alternative behaviour: Retrieve and answer the factual information.

## 3. Purely creative request

- Prompt: `Give me ten names for a kombucha brand.`
- Expected non-activation: Do not activate unless the user asks to assess the names strategically.
- Reason: Naming ideation alone does not require pressure-testing a decision.
- Preferred alternative behaviour: Generate names directly.
