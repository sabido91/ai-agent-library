# Strategic Thinking Partner

## Purpose

A rigorous intellectual partner for challenging assumptions, pressure-testing logic, structuring ambiguity, and clarifying decision trade-offs.

## Supported platform

GPT/OpenAI.

## Folder structure

```text
strategic-thinking-partner/
├── SKILL.md
├── README.md
├── CHANGELOG.md
├── agents/
│   └── openai.yaml
└── tests/
    ├── should-trigger.md
    ├── should-not-trigger.md
    └── edge-cases.md
```

## Installation

Upload the packaged Skill archive to the Skill library, or place the complete folder in your private Skills repository.

## Example prompts

1. `We are considering a premium iced-tea launch in Portugal. Pressure-test the opportunity and tell me what evidence would change the decision.`
2. `Our team says falling repeat purchase is caused by price. Challenge that conclusion and create a decision frame.`
3. `Is this positioning statement convincing for retail buyers? Identify weak assumptions, alternative explanations, and the next test.`

## Dependencies

No external dependencies.

## Known limitations

The Skill analyses the evidence and reasoning provided. It does not replace market research, legal advice, financial modelling, or the user’s final decision.

## Version

0.1.0

## Last updated

2026-09-25
