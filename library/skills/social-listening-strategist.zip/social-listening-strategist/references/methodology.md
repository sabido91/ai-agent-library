# Metodologia e regras de evidencia

## Unidade e corpus
Definir a unidade antes de contar. N analisado inclui apenas unidades abertas, lidas e codificadas. Documentar selecao, vieses e agregacoes.

## Descoberta e queries
Queries sao hipoteses de recuperacao. No modo web-based, decompor Boolean em pesquisas curtas e registar `discovery_query`, data e fonte. No modo platform-native, documentar sintaxe, filtros, testes, falsos positivos, lacunas e versao final congelada.

## Deduplicacao e qualidade
Excluir ou sinalizar duplicados, cross-posts, spam, bots, promocao de marca e itens sem conteudo substantivo. Preservar contraexemplos e opinioes minoritarias.

## Evidence strength
- Recurring: repetido em varios conteudos e idealmente mais de uma fonte/contexto.
- Emerging: repetido mas concentrado ou estreito.
- Isolated: pontual.
- Hypothesis: explicacao nao observada diretamente.

## Validacao
Percentagens interpretativas exigem validacao humana de 10 itens aleatorios ou recodificacao independente de pelo menos 20%. Sem validacao, usar contagens e linguagem qualitativa.

Pulse N < 30: sem percentagens e sem obrigacao de recodificacao formal. Pulse N 30-99: contagens descritivas permitidas; percentagens exigem validacao.

## Metricas
Sentiment requer codebook, N e validacao. SOV requer mesma janela, fontes e queries comparaveis. Trends requerem serie temporal consistente. Resultados de pesquisa nao equivalem a volume. Purchase intent textual nao e prevalencia.

## Contextos e privacidade
Preferir segmentacao comportamental. Nao inferir atributos pessoais sensiveis. Anonimizar usernames quando nao forem necessarios.

## Triangulacao
Separar corpus social, supporting evidence e hipoteses internas. Classificar Supported, Social-only, Contradicted ou Unresolved. A atualidade depende da rapidez de mudanca do fenomeno. Evidencia com mais de 18 meses sobre claims, preco, portfolio, canais, concorrencia, tendencias ou comportamentos digitais e potencialmente desatualizada. Evidencia estrutural mais antiga pode enquadrar, mas nao provar mercado contemporaneo. Usar `Unresolved` ou `Supported with historical/contextual evidence` quando houver desalinhamento temporal.

## Rastreabilidade
Preservar URL, data de acesso, query de descoberta, excerto e decisao de inclusao. Uma citacao ilustra; nao prova sozinha.

## Recomendacao de proxima evidencia
Associar gaps a entrevistas, survey, concept test, A/B test, vendas/CRM, novo listening ou platform-native listening.

## Creators e autoria
Separar consumer spontaneous, consumer response/comment, creator/influencer, brand, retailer, editorial/media, expert/professional e unknown. Conteudo de creator nao e automaticamente voz espontanea; assinalar incentivos e separar comentarios.

## Deduplicacao operacional
Agrupar reposts, cross-posts, conteudo replicado, comentarios automaticos, texto substancialmente identico e reviews copiadas. Usar `duplicate_group_id` e contar novamente apenas quando houver contexto, reacao ou audiencia materialmente diferente.
