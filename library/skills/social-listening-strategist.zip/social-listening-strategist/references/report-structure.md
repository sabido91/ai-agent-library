# Estrutura do Final Report

## Abertura obrigatoria
`Resposta curta:` resposta direta em 1-2 frases, calibrada a evidencia.

## Access declaration
Usar o bloco definido em `templates.md` antes do Executive Summary.

## Escolha de formato
Pulse quando N < 100; em qualquer corpus web-based sem cobertura sistematica; ou quando ha fontes altamente enviesadas, falta de metadados ou selecao oportunistica. Full apenas com N >= 100, corpus estruturado, mercados/periodo/unidade declarados, validacao quando aplicavel e cobertura suficiente. N sozinho nao prova qualidade.

## Pulse
1. Executive Summary: 3-7 achados e implicacoes.
2. Scope & Coverage: modo, fontes, periodo, N, amostragem, acessos falhados, vieses e supporting evidence separada.
3. Themes + Consumer Language: sinal, evidencia, forca, fontes, contraexemplos, interpretacao e implicacao.
4. Needs, Barriers & Tensions: jobs, drivers, barriers, trade-offs, ocasioes e perfis comportamentais.
5. Strategic Implications & Recommended Actions: priorizar por impacto, evidencia, complexidade e urgencia.
6. What we know / What we think / What we don't know / What to test next, incluindo decisao desbloqueada, metodo e criterio de avanco/adaptacao/abandono.

Para N < 30, nao apresentar percentagens interpretativas e incluir exemplos e contraexemplos. Para N 30-99, contagens descritivas sao permitidas, mas percentagens interpretativas exigem validacao.

## Full
1. Executive Summary.
2. Access declaration.
3. Scope & Corpus.
4. Coverage & Limitations.
5. Volume & Trends, apenas quando suportado.
6. Sentiment, apenas com validacao.
7. Themes & Emerging Topics.
8. Consumer/Audience Contexts.
9. Needs, Jobs, Drivers & Barriers.
10. Brand/Product Comparison, apenas com cobertura comparavel.
11. Consumer Language & Representative Evidence.
12. Tensions/Unmet Needs.
13. Strategic Implications.
14. Recommended Actions.
15. What we know / What we think / What we don't know / What to test next, incluindo decisao desbloqueada, metodo e criterio de avanco/adaptacao/abandono.

Quando uma metrica nao e suportada, escrever `Nao suportado pelo corpus` e indicar os dados necessarios.
