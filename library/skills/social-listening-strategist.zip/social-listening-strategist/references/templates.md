# Templates

## Access declaration
- Execution mode:
- Scope / business question:
- Platforms effectively consulted:
- Platforms attempted but not accessible:
- Access type: web-indexed / direct platform / API / export / user-provided file
- Period covered:
- Market and language coverage:
- Unit of analysis:
- N located:
- N effectively inspected:
- N included in final corpus:
- Selection/sampling method:
- Deduplication method:
- Material limitations:

## Research Stream Log
| Stream ID | Pergunta de investigacao | Relacao com decisao | Inclusoes/variacoes | Exclusoes/ruido | Mercado/idioma | Fontes | Unidade | Output | Limitacoes |
|---|---|---|---|---|---|---|---|---|---|

## Search Query Log
| Query ID | Stream ID | Fonte/motor | Query ou termos usados | Mercado/lingua | Periodo/filtros | Data de pesquisa | Resultado/ajuste | Limitacoes |
|---|---|---|---|---|---|---|---|---|

## Source Access Log
| Plataforma | Tentada | Acessivel | Tipo de acesso | Conteudo analisavel | Limitacao |
|---|---:|---:|---|---|---|

## Corpus Log
| ID | source_url | source_access_date | discovery_query | source_type | content_date | Mercado/lingua | Marca/produto | author_type | inclusion_decision | inclusion_reason | duplicate_group_id | raw_text/excerto | coding_status | evidence_strength |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|

Regras:
- `author_type`: consumer spontaneous / consumer response-comment / creator-influencer / brand / retailer / editorial-media / expert-professional / unknown.
- `inclusion_decision`: include / exclude / ambiguous.
- N localizado pode ser ND.
- N analisado inclui apenas unidades efetivamente abertas e inspecionadas.
- Separar fontes/unidades diferentes ou explicar agregacao.

## Evidence Coding
| ID | Referencia | Tema | Subtema | Sentimento | Need/Job | Driver/Barrier | Tensao | Ocasiao/contexto | Comparacao | Citacao curta | Interpretation | Evidence strength |
|---|---|---|---|---|---|---|---|---|---|---|---|---|

## Coding Validation Log
| Item | ID conteudo | Rotulo original | Rotulo validacao | Acordo? | Nota/correcao |
|---|---|---|---|---|---|

Na recodificacao independente, resumir N total, N recodificado, percentagem recodificada, concordancia simples e divergencias materiais.

## Supporting Evidence Log
| ID | Fonte | Tipo | Mercado/populacao | Data | Diferenca vs corpus | Estado temporal | Evidencia | Limitacoes | Relacao com social signal |
|---|---|---|---|---|---|---|---|---|---|

## Hypothesis Board / Decision Matrix
| Insight ou hipotese | Evidencia social | Supporting evidence | Estado | Confianca | Implicacao | O que falta | Decisao/proximo teste |
|---|---|---|---|---|---|---|---|

## Evidence strength por unidade
- High: relato direto e especifico de experiencia, contexto e consequencia.
- Medium: opiniao ou recomendacao clara, mas com contexto limitado.
- Low: mencao breve, ambigua, indireta ou sem experiencia relatada.
- Exclude: promocao, spam, duplicado, publicidade nao assinalada, fora de scope ou sem relevancia interpretavel.

A escala mede utilidade qualitativa, nao representatividade, veracidade objetiva nem influencia social.
