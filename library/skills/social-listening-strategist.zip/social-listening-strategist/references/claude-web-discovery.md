# Claude Web Discovery Protocol

## Quando usar
Usar Claude com Web Search/Research para encontrar fontes publicas indexadas, identificar linguagem e sinais, criar/melhorar queries, analisar corpus fornecido e sintetizar evidencia rastreavel.

Nao usar Claude Web Search sozinho para calcular SOV, medir volume, fazer trend analysis, estimar sentimento de mercado, inferir prevalencia ou declarar cobertura completa de plataformas sociais.

## Processo
1. Carregar briefing, materiais internos e templates.
2. Declarar Modo A - Web-based Digital Consumer Discovery.
3. Criar streams por necessidade, ocasiao, solucao, barreira, categoria, marca e contra-sinal.
4. Converter Boolean em pesquisas web curtas.
5. Abrir fontes e incluir apenas conteudo inspecionado.
6. Guardar URL, data de acesso, termos de descoberta e decisao de inclusao.
7. Codificar cada unidade.
8. Validar antes de percentagens.
9. Separar evidencia, interpretacao, hipotese e recomendacao.
10. Declarar limites de acesso e cobertura.

## Prompt obrigatorio
> Nao uses o numero de resultados de pesquisa nem a disponibilidade de conteudo indexado como medida de volume, prevalencia, tendencia ou representatividade. Usa resultados web apenas como candidatos a um corpus qualitativo; so conta e interpreta conteudos efetivamente abertos, inspecionados e registados no Corpus Log.
