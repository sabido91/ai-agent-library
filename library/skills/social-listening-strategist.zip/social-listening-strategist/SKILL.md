---
name: social-listening-strategist
description: Pesquisar e analisar conversas publicas sobre categorias, marcas, produtos, problemas ou comportamentos, construindo um corpus auditavel e convertendo social signals em insights estrategicos, hipoteses e proximos testes. Usar para social listening, reviews, foruns, redes sociais, percecao de marca ou categoria, necessidades, jobs-to-be-done, drivers, barreiras, tensoes, linguagem do consumidor, comparacao de marcas, sentimento, share of voice, tendencias ou recomendacoes baseadas em conversa publica.
---

# Social Listening Strategist

## Missao
Pesquisar conversas publicas relevantes, construir um corpus auditavel e converter sinais sociais em implicacoes estrategicas e proximos testes. Tratar social listening como investigacao exploratoria e estrategica, nunca como mera contagem de mencoes nem como verdade de mercado.

## Principios obrigatorios
- Responder primeiro a pergunta de negocio com `Resposta curta:` em uma ou duas frases.
- Auditar antes de concluir: incluir um `Access declaration` com modo de execucao, fontes/plataformas consultadas e nao acessiveis, tipo de acesso, mercados, idiomas, periodo, unidade de analise, selecao, deduplicacao, N localizado quando conhecido, N efetivamente inspecionado, N incluido e limitacoes materiais.
- Contar apenas unidades abertas, lidas e registadas no Corpus Log.
- Remover ou assinalar duplicados, reposts, cross-posts, spam, respostas automaticas e promocao de marca.
- Separar `Observed evidence`, `Interpretation`, `Hypothesis` e `Recommendation/Opportunity`.
- Separar `Social Listening Corpus`, `Supporting Evidence` e `Internal Hypothesis`.
- Nao fabricar SOV, volume, trends, prevalencia ou sentimento percentual.
- A ausencia de resultados nao prova ausencia de conversa, necessidade ou comportamento.
- Preservar URLs, datas de acesso, queries de descoberta e decisoes de inclusao.
- Priorizar decisoes e testes, sem generalizar indevidamente.

## Access declaration obrigatoria
No inicio de qualquer relatorio, imediatamente depois de `Resposta curta:`, declarar:
- Execution mode;
- Scope / business question;
- Market(s) and language(s);
- Period covered;
- Platforms/sources effectively consulted;
- Platforms/sources attempted but not accessible;
- Access type: web-indexed / direct platform / API / export / user-provided corpus;
- Unit of analysis;
- N located, quando conhecido;
- N effectively inspected;
- N included in final corpus;
- Selection/sampling method;
- Deduplication method;
- Material limitations.

## Modos de execucao
Declarar o modo no inicio do trabalho e no bloco `Access declaration`.

### Regra de precedencia
Antes de executar qualquer pesquisa, declarar o modo. Se o utilizador nao o indicar, inferir o modo mais conservador:
- URLs, pesquisa web, resultados indexados ou Claude Web Search: Modo A;
- CSV, XLSX, JSON ou export fornecido: Modo C;
- acesso confirmado a ferramenta, API ou plataforma nativa: Modo B;
- combinacao de dois ou mais: Modo D.
Nunca assumir Modo B apenas porque o pedido usa a expressao `social listening`.

### Modo A - Web-based Digital Consumer Discovery
Usar quando a recolha e feita atraves de pesquisa web, motores de pesquisa, paginas indexadas, reviews publicas, foruns ou URLs fornecidos pelo utilizador.

Objetivos:
- descobrir linguagem, tensoes, ocasioes, alternativas, barreiras e hipoteses;
- construir um corpus qualitativo, auditavel e limitado ao conteudo publico efetivamente acessivel;
- preparar prioridades e queries para investigacao posterior.

Limites:
- nao afirmar cobertura completa de rede social, marca, categoria ou mercado;
- nao inferir volume real, SOV, tendencia temporal ou prevalencia populacional a partir de resultados indexados;
- nao assumir acesso a conteudo privado, nao indexado, removido, geolocalizado ou sujeito a login;
- nao usar o numero de resultados do motor de pesquisa como metrica.

Queries:
- tratar queries como mapas de pesquisa, nao como Boolean executavel com cobertura garantida;
- decompor logica Boolean em pesquisas curtas e especificas;
- registar os termos usados para localizar cada fonte;
- abrir o conteudo original antes de o contar ou codificar.

Output:
- designar o trabalho como `Web-based Digital Consumer Discovery` ou `Exploracao digital qualitativa`;
- usar Pulse por defeito, mesmo com N >= 100, se a cobertura nao for sistematica;
- declarar plataformas consultadas, tipo de acesso e limites de indexacao.

### Modo B - Platform-native Social Listening
Usar quando existe acesso real a plataforma de listening, API, pesquisa nativa ou export estruturado com posts, comentarios, reviews e metadados.

Requisitos:
- guardar query final, filtros, periodo, fontes, data de recolha e deduplicacao;
- declarar se a exportacao e total, amostral ou limitada;
- distinguir posts, comentarios, autores e engagement;
- validar codificacao antes de percentagens interpretativas;
- calcular metricas apenas dentro da cobertura efetivamente disponivel.

### Modo C - Corpus ou export fornecido pelo utilizador
Usar quando o utilizador fornece um corpus sem acesso direto a ferramenta ou plataforma de origem. Declarar origem, cobertura conhecida, campos, filtros precedentes e limitacoes herdadas.

Se o export vier de uma ferramenta platform-native:
- classificar a recolha original como Modo B;
- classificar a analise atual como Modo C, baseada em export de Modo B;
- declarar filtros, janela temporal, campos e limitacoes herdadas.

Se a origem nao for conhecida ou verificavel, tratar como Modo C e nao assumir cobertura, query, deduplicacao ou completude.

### Modo D - Abordagem hibrida
Usar quando se combinam quaisquer modos. Manter os Ns, metodos e limitacoes separados antes da sintese.

## Inputs
Aceitar: pergunta de negocio, categoria, marcas, produtos, comportamentos, mercados, linguas, periodo, fontes, concorrentes, modo de recolha e supporting evidence. Se o pedido for generico, inferir scope razoavel; pedir clarificacao apenas quando a ausencia de mercado, periodo ou pergunta impedir analise util.

## Workflow

### 0. Evidence intake e triangulacao
Classificar tudo em Social Listening Corpus, Supporting Evidence ou Internal Hypothesis. Nunca somar supporting evidence ao N social. Classificar conclusoes como Supported, Social-only, Contradicted ou Unresolved. Avaliar a atualidade segundo a rapidez de mudanca do fenomeno. Para claims, preco, portfolio, disponibilidade, tendencias, conversa social, canais, concorrencia e comportamentos digitais, evidencia com mais de 18 meses deve ser marcada como potencialmente desatualizada. Para necessidades humanas estruturais, modelos comportamentais, metodologia, ciencia consolidada ou dados demograficos estaveis, evidencia mais antiga pode enquadrar, mas nao provar o mercado contemporaneo. Evidencia temporalmente desalinhada nao eleva, por si so, uma conclusao para `Supported`; usar `Unresolved` ou `Supported with historical/contextual evidence`, conforme a fonte.

### 1. Definir scope
Fixar pergunta, decisao, categoria/marca, mercados, linguas, periodo, fontes, concorrentes e unidade de analise.

### 1.5 Selecionar modo e desenhar streams
Para cada stream registar:
- pergunta de investigacao e relacao com a decisao;
- termos de inclusao, variacoes linguisticas e exclusoes;
- mercados, idiomas e fontes prioritarias;
- criterio de relevancia e unidade de analise;
- output esperado e limitacoes antecipadas.

Nao criar uma mega-query para necessidades, ocasioes, alternativas, barreiras e marcas.

No Modo A, converter Boolean em pesquisas curtas, executar separadamente, registar e inspecionar o original. No Modo B, adaptar a sintaxe a ferramenta, testar numa amostra, registar falsos positivos e lacunas, ajustar e congelar a versao de recolha.

### 2. Pesquisar multi-fonte
Privilegiar voz espontanea em reviews, foruns, comunidades, video/comentarios, retailers e marketplaces. Tratar imprensa e blogs como contexto, salvo se a pergunta exigir conteudo editorial ou especialista. Declarar plataformas fechadas ou parcialmente indexadas.

### 2.5 Tratar autoria, creators e deduplicacao
Classificar, quando possivel: Consumer spontaneous, Consumer response/comment, Creator/influencer, Brand, Retailer, Editorial/media, Expert/professional ou Unknown. Conteudo de creator nao e automaticamente voz espontanea. Assinalar parcerias, publicidade, afiliacao ou incentivo. Separar conteudo do creator, comentarios de utilizadores, comunicacao de marca e conteudo editorial.

Nao contar como unidades independentes reposts sem comentario novo, o mesmo conteudo replicado, cross-posts de creator/marca, comentarios automaticos, texto substancialmente identico ou reviews copiadas/incentivadas em massa. Manter referencia no Corpus Log com `duplicate_group_id`. Conservar republicacoes apenas quando acrescentem contexto, reacao ou audiencia materialmente diferente.

### 3. Construir Corpus Log
Usar `references/templates.md`. Para cada unidade registar, quando disponivel: ID, source_url, source_access_date, discovery_query, source_type, content_date, mercado/lingua, marca/produto, author_type, inclusion_decision, inclusion_reason, duplicate_group_id, raw_text/excerto, coding_status e evidence_strength.

### 4. Codificar evidencia
Capturar tema, subtema, sentimento, need/job, driver/barrier, tensao, ocasiao, sinal de procura, comparacao espontanea, linguagem, mercado e evidence strength. Nao inferir demografia ou atributos sensiveis pelo estilo de escrita.

### 5. Validar antes de percentagens
Para percentagens interpretativas, exigir validacao humana de 10 itens aleatorios ou recodificacao independente de pelo menos 20% do corpus. Sem validacao, usar contagens e forca qualitativa com limitacao explicita.

Excecao operacional:
- Pulse N < 30: sem percentagens; recodificacao formal nao obrigatoria; incluir exemplos, contraexemplos e limitacao.
- Pulse N 30-99: contagens descritivas permitidas; sem percentagens interpretativas sem validacao.

### 6. Avaliar forca
Evidence strength por unidade:
- High: relato direto e especifico de experiencia, contexto e consequencia;
- Medium: opiniao ou recomendacao clara, com contexto limitado;
- Low: mencao breve, ambigua, indireta ou sem experiencia relatada;
- Exclude: promocao, spam, duplicado, publicidade nao assinalada, fora de scope ou sem relevancia interpretavel.
Esta escala mede utilidade qualitativa, nao representatividade, veracidade objetiva ou influencia social.

Forca do padrao:
- Recurring qualitative signal: repetido em varios conteudos e, idealmente, mais de uma fonte/contexto.
- Emerging signal: repetido, mas concentrado ou com base estreita.
- Isolated signal: pontual, util para hipotese.
- Hypothesis: explicacao ainda nao observada diretamente.

### 7. Calcular metricas apenas quando suportadas
Sentiment requer N, codebook e validacao. SOV requer janela, fontes e queries comparaveis. Trends requerem serie temporal consistente. Intencao de compra e sinal textual, nao metrica representativa.

### 8. Sintetizar para decisao
Priorizar 3-7 insights fortes sobre temas, contextos, needs, jobs, drivers, barriers, tensoes, linguagem, implicacoes e testes.

### 9. Escolher formato e produzir relatorio
Pulse quando N < 100, quando o corpus web-based nao tem cobertura sistematica, ou quando ha enviesamento/falta de metadados/selecao oportunistica. Full apenas quando N >= 100, corpus estruturado, scope e unidade declarados, codificacao validada quando aplicavel e cobertura suficiente. O numero de itens nao prova qualidade ou representatividade.

Seguir `references/report-structure.md`. Terminar sempre com:
- What we know: evidencia observada e padroes mais robustos dentro do corpus;
- What we think: interpretacoes e hipoteses plausiveis, com confianca indicada;
- What we don't know: lacunas, contradicoes, cobertura insuficiente e questoes sem resposta;
- What to test next: proxima acao de investigacao, decisao que desbloqueia, metodo recomendado e criterio de avanco, adaptacao ou abandono.

## Prompt obrigatorio no Modo A
> Nao uses o numero de resultados de pesquisa nem a disponibilidade de conteudo indexado como medida de volume, prevalencia, tendencia ou representatividade. Usa resultados web apenas como candidatos a um corpus qualitativo; so conta e interpreta conteudos efetivamente abertos, inspecionados e registados no Corpus Log.

## Recursos
- `references/methodology.md`
- `references/templates.md`
- `references/report-structure.md`
- `references/claude-web-discovery.md`
